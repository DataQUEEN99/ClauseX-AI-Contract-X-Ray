import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LandingSections } from './components/LandingSections';
import { UploadModal } from './components/UploadModal';
import { ProcessingSequence } from './components/ProcessingSequence';
import { OverallRiskScoreCard } from './components/OverallRiskScoreCard';
import { ContractXRayViewer } from './components/ContractXRayViewer';
import { ReportView } from './components/ReportView';
import { DisclaimerFooter } from './components/DisclaimerFooter';
import { DEMO_CONTRACTS } from './data/demoContracts';
import { AnalysisResult, DemoContract } from './types/contract';

export default function App() {
  const [viewState, setViewState] = useState<'LANDING' | 'PROCESSING' | 'RESULTS'>('LANDING');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  
  const [currentAnalysis, setCurrentAnalysis] = useState<AnalysisResult | null>(null);
  const [processingFilename, setProcessingFilename] = useState<string>('');
  const [processingError, setProcessingError] = useState<string | null>(null);

  // Helper to convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  // Helper to convert text file to string
  const fileToText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsText(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  // 1. JUDGE DEMO MODE TRIGGER (60-second instant high-impact demo)
  const handleLaunchJudgeDemo = () => {
    const demo = DEMO_CONTRACTS[0]; // Apartment Lease Agreement
    setProcessingFilename(demo.precomputedAnalysis.documentName);
    setProcessingError(null);
    setCurrentAnalysis(demo.precomputedAnalysis);
    setViewState('PROCESSING');
  };

  // 2. DEMO CONTRACT SELECTION
  const handleSelectDemo = (demo: DemoContract) => {
    setProcessingFilename(demo.precomputedAnalysis.documentName);
    setProcessingError(null);
    setCurrentAnalysis(demo.precomputedAnalysis);
    setViewState('PROCESSING');
  };

  // 3. FILE UPLOAD HANDLER
  const handleSelectFile = async (file: File) => {
    setProcessingFilename(file.name);
    setProcessingError(null);
    setCurrentAnalysis(null);
    setViewState('PROCESSING');

    try {
      let payload: any = { filename: file.name };

      if (file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf') {
        const base64Data = await fileToBase64(file);
        payload.pdfBase64 = base64Data;
        payload.mimeType = 'application/pdf';
      } else {
        const textContent = await fileToText(file);
        payload.text = textContent;
      }

      // Call Express Server Endpoint /api/analyze
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server analysis error (Status ${res.status})`);
      }

      const analysisResult: AnalysisResult = await res.json();
      setCurrentAnalysis(analysisResult);
    } catch (err: any) {
      console.warn('Analysis error encountered:', err.message);
      // Fail-safe fallback mode
      setProcessingError(
        `Live AI analysis is temporarily unavailable (${err.message || 'Network/Key'}). You can continue with Demo Analysis.`
      );
    }
  };

  // 4. FALLBACK TO DEMO ANALYSIS
  const handleFallbackToDemo = () => {
    const fallbackDemo = DEMO_CONTRACTS[0];
    setProcessingFilename(fallbackDemo.precomputedAnalysis.documentName);
    setCurrentAnalysis(fallbackDemo.precomputedAnalysis);
    setProcessingError(null);
    setViewState('RESULTS');
  };

  // Reset to Landing Page
  const handleReset = () => {
    setViewState('LANDING');
    setCurrentAnalysis(null);
    setProcessingError(null);
    setIsUploadOpen(false);
    setIsReportOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#F0F0F0] flex flex-col font-sans selection:bg-[#CCFF00] selection:text-black antialiased">
      
      {/* Top Navbar */}
      <Navbar
        onOpenUpload={() => setIsUploadOpen(true)}
        onLaunchJudgeDemo={handleLaunchJudgeDemo}
        hasActiveAnalysis={viewState === 'RESULTS'}
        onReset={handleReset}
      />

      {/* Main Content View Switcher */}
      <main className="flex-1">
        {viewState === 'LANDING' && (
          <>
            <Hero
              onOpenUpload={() => setIsUploadOpen(true)}
              onLaunchDemo={handleLaunchJudgeDemo}
            />
            <LandingSections
              onOpenUpload={() => setIsUploadOpen(true)}
              onLaunchDemo={handleLaunchJudgeDemo}
            />
          </>
        )}

        {viewState === 'PROCESSING' && (
          <ProcessingSequence
            filename={processingFilename}
            isReady={currentAnalysis !== null}
            error={processingError}
            onComplete={() => setViewState('RESULTS')}
            onFallbackToDemo={handleFallbackToDemo}
          />
        )}

        {viewState === 'RESULTS' && currentAnalysis && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-fade-in">
            {/* Overall Risk Score Card */}
            <OverallRiskScoreCard
              analysis={currentAnalysis}
              onOpenReport={() => setIsReportOpen(true)}
            />

            {/* Visual Contract X-Ray Viewer */}
            <ContractXRayViewer
              documentName={currentAnalysis.documentName}
              documentType={currentAnalysis.documentType}
              clauses={currentAnalysis.clauses}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <DisclaimerFooter />

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onSelectFile={handleSelectFile}
        onSelectDemo={handleSelectDemo}
      />

      {/* Printable Report Modal */}
      {isReportOpen && currentAnalysis && (
        <ReportView
          analysis={currentAnalysis}
          onClose={() => setIsReportOpen(false)}
        />
      )}

    </div>
  );
}
