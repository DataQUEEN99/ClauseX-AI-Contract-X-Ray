import { Clause, CategoryBreakdownItem, RiskCategory, RiskLevel } from '../types/contract';

export function calculateDeterministicRiskScore(clauses: Clause[]): {
  overallRiskScore: number;
  riskLevelLabel: 'LOW REVIEW SIGNAL' | 'MODERATE REVIEW SIGNAL' | 'HIGH REVIEW SIGNAL' | 'VERY HIGH REVIEW SIGNAL';
  categoryBreakdown: CategoryBreakdownItem[];
} {
  if (!clauses || clauses.length === 0) {
    return {
      overallRiskScore: 0,
      riskLevelLabel: 'LOW REVIEW SIGNAL',
      categoryBreakdown: [],
    };
  }

  // Base score values
  const BASE_SCORES: Record<RiskLevel, number> = {
    LOW: 15,
    MEDIUM: 45,
    HIGH: 80,
  };

  let totalWeightedScore = 0;
  let totalWeights = 0;
  let highRiskCount = 0;

  // Category mapping tracker
  const categoryMap = new Map<RiskCategory, {
    totalScore: number;
    count: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
  }>();

  for (const clause of clauses) {
    const base = BASE_SCORES[clause.riskLevel] || 30;
    const confidenceWeight = Math.max(0.5, Math.min(1.0, (clause.confidence || 85) / 100));
    
    // Additional impact weight for high severity clauses
    const severityMultiplier = clause.riskLevel === 'HIGH' ? 1.25 : clause.riskLevel === 'MEDIUM' ? 1.0 : 0.75;
    const weightedVal = base * confidenceWeight * severityMultiplier;
    
    totalWeightedScore += weightedVal;
    totalWeights += 1;

    if (clause.riskLevel === 'HIGH') {
      highRiskCount++;
    }

    // Track category metrics
    const cat = clause.category || 'Other';
    const existing = categoryMap.get(cat) || {
      totalScore: 0,
      count: 0,
      highCount: 0,
      mediumCount: 0,
      lowCount: 0,
    };

    existing.count += 1;
    existing.totalScore += base;
    if (clause.riskLevel === 'HIGH') existing.highCount += 1;
    else if (clause.riskLevel === 'MEDIUM') existing.mediumCount += 1;
    else existing.lowCount += 1;

    categoryMap.set(cat, existing);
  }

  // Compute average score
  let averageScore = totalWeightedScore / Math.max(1, totalWeights);

  // High risk clauses multiplier boost (multiple high risk clauses amplify overall risk signal)
  if (highRiskCount >= 3) {
    averageScore = Math.min(98, averageScore * 1.2);
  } else if (highRiskCount === 2) {
    averageScore = Math.min(95, averageScore * 1.1);
  } else if (highRiskCount === 1) {
    averageScore = Math.min(90, averageScore * 1.05);
  }

  const overallRiskScore = Math.round(Math.max(5, Math.min(100, averageScore)));

  // Label mapping
  let riskLevelLabel: 'LOW REVIEW SIGNAL' | 'MODERATE REVIEW SIGNAL' | 'HIGH REVIEW SIGNAL' | 'VERY HIGH REVIEW SIGNAL';
  if (overallRiskScore <= 25) {
    riskLevelLabel = 'LOW REVIEW SIGNAL';
  } else if (overallRiskScore <= 50) {
    riskLevelLabel = 'MODERATE REVIEW SIGNAL';
  } else if (overallRiskScore <= 75) {
    riskLevelLabel = 'HIGH REVIEW SIGNAL';
  } else {
    riskLevelLabel = 'VERY HIGH REVIEW SIGNAL';
  }

  // Build category breakdown array
  const categoryBreakdown: CategoryBreakdownItem[] = Array.from(categoryMap.entries()).map(
    ([category, stats]) => {
      const avgCatScore = Math.round(stats.totalScore / stats.count);
      return {
        category,
        score: Math.min(100, Math.max(10, avgCatScore)),
        count: stats.count,
        highCount: stats.highCount,
        mediumCount: stats.mediumCount,
        lowCount: stats.lowCount,
      };
    }
  );

  // Sort breakdown by risk score descending
  categoryBreakdown.sort((a, b) => b.score - a.score);

  return {
    overallRiskScore,
    riskLevelLabel,
    categoryBreakdown,
  };
}
