import { DemoContract } from '../types/contract';

export const DEMO_CONTRACTS: DemoContract[] = [
  {
    id: 'rental-lease-01',
    title: 'Apartment Lease Agreement',
    type: 'Rental Agreement',
    description: 'Standard residential lease with strict early termination penalties and deposit forfeiture clauses.',
    iconName: 'Home',
    fileSize: '48 KB',
    fullText: `RESIDENTIAL LEASE AGREEMENT

This Residential Lease Agreement ("Agreement") is entered into by and between Oakridge Realty Management LLC ("Landlord") and John Doe ("Tenant").

SECTION 1. LEASE TERM & OCCUPANCY
1.1 Term: The term of this Lease shall commence on October 1, 2025 and expire on September 30, 2026.
1.2 Automatic Renewal: Unless written notice of non-renewal is delivered by Tenant via certified mail exactly ninety (90) days prior to lease expiration, this Agreement shall automatically renew for a successive 12-month term at a rent increase of 12%.

SECTION 2. RENT AND PAYMENT TERMS
2.1 Monthly Rent: Rent is $2,400 per month, due strictly on the 1st day of each month.
2.2 Late Fee: Rent payments received after 11:59 PM on the 2nd day of the month shall incur an immediate flat late fee of $250 plus $25 per day until paid in full.
2.3 Payment Method: Rent must be paid through Landlord's designated digital portal which applies a non-negotiable 3.5% transaction processing charge.

SECTION 3. SECURITY DEPOSIT & FORFEITURE
3.1 Security Deposit: Tenant shall deposit $4,800 as security.
3.2 Deposit Forfeiture: Landlord reserves the absolute right to retain 100% of the Security Deposit if Tenant terminates prior to the full 12-month term for any reason whatsoever, regardless of re-renting status or replacement tenants.

SECTION 4. EARLY TERMINATION & PENALTY
4.1 Early Termination Fee: In the event Tenant seeks to vacate prior to lease end, Tenant agrees to pay an liquidated damages fee equal to six (6) full months of rent ($14,400) immediately upon notice.
4.2 Acceleration of Rent: Upon any event of default or early notice, Landlord may declare all remaining rent for the balance of the lease term immediately due and payable.

SECTION 5. MAINTENANCE & ENTRY RIGHTS
5.1 Maintenance Obligations: Tenant shall be solely responsible for all maintenance, plumbing repairs, HVAC servicing, and appliance replacements costing up to $750 per occurrence.
5.2 Landlord Entry: Landlord and its contractors reserve the right to enter the Premises at any time between 7:00 AM and 10:00 PM without prior written notice for general inspection or maintenance assessments.

SECTION 6. GOVERNING LAW & DISPUTE RESOLUTION
6.1 Mandatory Arbitration: Any dispute arising under this Agreement shall be submitted to binding private arbitration in Wilmington, Delaware. Tenant waives all rights to a jury trial or class action participation.
6.2 Legal Fees: Tenant agrees to reimburse Landlord for all attorney and court fees incurred in enforcing any section of this Agreement, regardless of formal judgment outcome.`,
    precomputedAnalysis: {
      documentName: 'Apartment Lease Agreement.pdf',
      documentType: 'Residential Lease',
      overallRiskScore: 78,
      riskLevelLabel: 'VERY HIGH REVIEW SIGNAL',
      summary: 'This residential lease contains several unusually restrictive terms, including a 6-month rent early termination penalty ($14,400), automatic 12-month renewal with a 90-day certified mail requirement, unannounced 7 AM entry rights, and total tenant liability for maintenance up to $750.',
      analyzedAt: new Date().toISOString(),
      isFallback: false,
      disclaimer: 'ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional.',
      recommendations: [
        'Negotiate the early termination fee down from 6 months to 1–2 months rent.',
        'Request 24 hours advance written notice for non-emergency landlord entry.',
        'Cap tenant maintenance responsibility to small routine repairs under $75–$100.',
        'Shorten the non-renewal notice window from 90 days to 30 or 60 days.'
      ],
      categoryBreakdown: [
        { category: 'Termination', score: 85, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Penalty', score: 80, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Deposit', score: 80, count: 1, highCount: 1, mediumCount: 0, lowCount: 0 },
        { category: 'Service obligations', score: 65, count: 2, highCount: 0, mediumCount: 2, lowCount: 0 },
        { category: 'Notice period', score: 60, count: 1, highCount: 0, mediumCount: 1, lowCount: 0 },
        { category: 'Dispute resolution', score: 55, count: 1, highCount: 0, mediumCount: 1, lowCount: 0 },
        { category: 'Payment', score: 20, count: 1, highCount: 0, mediumCount: 0, lowCount: 1 }
      ],
      clauses: [
        {
          id: 'lease-c1',
          text: '4.1 Early Termination Fee: In the event Tenant seeks to vacate prior to lease end, Tenant agrees to pay an liquidated damages fee equal to six (6) full months of rent ($14,400) immediately upon notice.',
          category: 'Termination',
          riskLevel: 'HIGH',
          confidence: 96,
          explanation: 'This clause charges 6 months of rent ($14,400) as a flat fee if you leave early, regardless of whether a new tenant moves in.',
          whyFlagged: 'A 6-month rent penalty significantly exceeds standard residential market patterns (which typically range from 1 to 2 months rent).',
          whatToCheck: 'Check if local tenant protection regulations limit early termination fees when a landlord re-leases the unit.',
          negotiationSuggestion: '"Could we amend Section 4.1 to a maximum early termination fee equal to two (2) months rent, provided 30 days notice is given?"'
        },
        {
          id: 'lease-c2',
          text: '3.2 Deposit Forfeiture: Landlord reserves the absolute right to retain 100% of the Security Deposit if Tenant terminates prior to the full 12-month term for any reason whatsoever, regardless of re-renting status.',
          category: 'Deposit',
          riskLevel: 'HIGH',
          confidence: 94,
          explanation: 'Automatic security deposit forfeiture is imposed in addition to early termination liquidated damages.',
          whyFlagged: 'Security deposits are legally designated for property damage repair, not double-dipping as extra penalty revenue.',
          whatToCheck: 'Verify whether double-penalizing deposit forfeiture on top of early termination fees is enforceable in your state.',
          negotiationSuggestion: '"Can we remove Section 3.2 so that the deposit is returned according to standard wear-and-tear inspection rules?"'
        },
        {
          id: 'lease-c3',
          text: '5.2 Landlord Entry: Landlord and its contractors reserve the right to enter the Premises at any time between 7:00 AM and 10:00 PM without prior written notice for general inspection or maintenance assessments.',
          category: 'Service obligations',
          riskLevel: 'MEDIUM',
          confidence: 90,
          explanation: 'Permits landlord entry across a 15-hour daily window with zero advance notice for routine inspections.',
          whyFlagged: 'Standard tenant quiet enjoyment rules require at least 24 hours prior written notice except in active emergencies.',
          whatToCheck: 'Confirm whether statutory right-of-entry laws mandate a minimum 24-hour advance written notification.',
          negotiationSuggestion: '"Could we update Section 5.2 to require at least 24 hours advance email notification for non-emergency entries?"'
        },
        {
          id: 'lease-c4',
          text: '1.2 Automatic Renewal: Unless written notice of non-renewal is delivered by Tenant via certified mail exactly ninety (90) days prior to lease expiration, this Agreement shall automatically renew for a successive 12-month term at a rent increase of 12%.',
          category: 'Notice period',
          riskLevel: 'MEDIUM',
          confidence: 88,
          explanation: 'A 90-day certified mail deadline is required to prevent an automatic 12-month extension with a 12% price hike.',
          whyFlagged: '90 days certified mail is an unusually narrow window that creates risk of accidental auto-renewal if missed.',
          whatToCheck: 'Check if 30 or 60 days email notification can be substituted for certified mail.',
          negotiationSuggestion: '"Can we reduce the notice requirement to 30 or 60 days written email notice rather than certified mail?"'
        },
        {
          id: 'lease-c5',
          text: '5.1 Maintenance Obligations: Tenant shall be solely responsible for all maintenance, plumbing repairs, HVAC servicing, and appliance replacements costing up to $750 per occurrence.',
          category: 'Service obligations',
          riskLevel: 'MEDIUM',
          confidence: 86,
          explanation: 'Shifts major property systems maintenance costs (plumbing/HVAC/appliances up to $750) directly onto the tenant.',
          whyFlagged: 'Structural, mechanical, and major building systems are standard landlord maintenance responsibilities.',
          whatToCheck: 'Ensure you are not paying to repair pre-existing aging building infrastructure.',
          negotiationSuggestion: '"Could we cap tenant repair liability at $75 per incident for minor routine items, excluding major appliances and HVAC systems?"'
        },
        {
          id: 'lease-c6',
          text: '6.1 Mandatory Arbitration: Any dispute arising under this Agreement shall be submitted to binding private arbitration in Wilmington, Delaware. Tenant waives all rights to a jury trial or class action participation.',
          category: 'Dispute resolution',
          riskLevel: 'MEDIUM',
          confidence: 82,
          explanation: 'Forces out-of-state private arbitration for local tenancy disputes and strips jury rights.',
          whyFlagged: 'Out-of-state arbitration increases tenant dispute costs dramatically relative to local small claims courts.',
          whatToCheck: 'Check whether local housing court jurisdiction applies automatically to residential tenancies.',
          negotiationSuggestion: '"Can we specify local court jurisdiction in the county where the property is situated?"'
        },
        {
          id: 'lease-c7',
          text: '2.1 Monthly Rent: Rent is $2,400 per month, due strictly on the 1st day of each month.',
          category: 'Payment',
          riskLevel: 'LOW',
          confidence: 98,
          explanation: 'Standard monthly rental obligation.',
          whyFlagged: 'Clause follows typical lease structure with clear date and amount.',
          whatToCheck: 'Verify grace period alignment with your payroll cycle.',
          negotiationSuggestion: '"Is a standard 5-day payment grace period included prior to late fee assessment?"'
        }
      ]
    }
  },
  {
    id: 'freelance-contract-02',
    title: 'Freelance Design Services Agreement',
    type: 'Freelance / Client Contract',
    description: 'Client agreement featuring Net-90 payment terms, infinite revisions, full IP transfer prior to payment, and unlimited indemnity.',
    iconName: 'Briefcase',
    fileSize: '36 KB',
    fullText: `FREELANCE SERVICES AGREEMENT

This Agreement is entered into by Client Systems Inc. ("Client") and Alex Taylor ("Contractor").

1. SCOPE OF SERVICES
Contractor shall deliver brand identity graphics, website assets, and UI components as requested by Client.

2. PAYMENT & INVOICING
2.1 Payment Terms: Invoices shall be processed on Net-90 terms from date of client internal approval.
2.2 Unlimited Revisions: Contractor agrees to provide unlimited revisions and layout modifications at no additional charge until Client expresses complete satisfaction.
2.3 Payment Withholding: Client reserves the right to withhold 50% of total project compensation if any milestone date is delayed by more than 48 hours.

3. INTELLECTUAL PROPERTY & OWNERSHIP
3.1 Immediate Assignment: Contractor hereby irrevocably assigns all right, title, and copyright in all work product to Client immediately upon creation, regardless of whether payment has been remitted.
3.2 Portfolio Restriction: Contractor shall not display, reference, or publish any created graphics in Contractor's professional portfolio without prior written authorization.

4. NON-COMPETE & RESTRICTIVE COVENANTS
4.1 Non-Compete: For a period of two (2) years following project completion, Contractor shall not perform design services for any entity operating in the digital software or web sector worldwide.

5. LIABILITY & INDEMNIFICATION
5.1 Unlimited Indemnity: Contractor agrees to defend, indemnify, and hold harmless Client from any and all claims, losses, damages, or legal costs arising out of or related to Contractor's work product without monetary cap.
5.2 Limitation of Client Liability: Client total aggregate liability for any breach shall strictly not exceed $100.00.`,
    precomputedAnalysis: {
      documentName: 'Freelance Design Agreement.pdf',
      documentType: 'Freelance Agreement',
      overallRiskScore: 84,
      riskLevelLabel: 'VERY HIGH REVIEW SIGNAL',
      summary: 'This freelance contract presents high risk to independent contractors due to Net-90 payment terms, immediate IP assignment before payment, unlimited revisions, a 2-year worldwide non-compete clause, and un-capped contractor indemnity.',
      analyzedAt: new Date().toISOString(),
      isFallback: false,
      disclaimer: 'ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional.',
      recommendations: [
        'Change payment terms from Net-90 to Net-15 or Net-30 with a 50% upfront deposit.',
        'Condition IP transfer strictly upon receipt of final full payment.',
        'Cap project revisions to 2–3 rounds, with additional revisions billed hourly.',
        'Remove or strictly narrow the 2-year worldwide non-compete covenant.'
      ],
      categoryBreakdown: [
        { category: 'Intellectual property', score: 90, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Non-compete', score: 88, count: 1, highCount: 1, mediumCount: 0, lowCount: 0 },
        { category: 'Liability', score: 85, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Payment', score: 75, count: 2, highCount: 1, mediumCount: 1, lowCount: 0 },
        { category: 'Service obligations', score: 60, count: 1, highCount: 0, mediumCount: 1, lowCount: 0 }
      ],
      clauses: [
        {
          id: 'free-c1',
          text: '3.1 Immediate Assignment: Contractor hereby irrevocably assigns all right, title, and copyright in all work product to Client immediately upon creation, regardless of whether payment has been remitted.',
          category: 'Intellectual property',
          riskLevel: 'HIGH',
          confidence: 97,
          explanation: 'Transfers full ownership of your designs to the client immediately upon creation, even if they never pay you.',
          whyFlagged: 'Standard creative contracts specify that IP rights transfer ONLY after full payment is received.',
          whatToCheck: 'Ensure you retain ownership until final invoice clearance.',
          negotiationSuggestion: '"Could we update Section 3.1 so that IP assignment takes effect upon Contractor\'s receipt of full final payment?"'
        },
        {
          id: 'free-c2',
          text: '4.1 Non-Compete: For a period of two (2) years following project completion, Contractor shall not perform design services for any entity operating in the digital software or web sector worldwide.',
          category: 'Non-compete',
          riskLevel: 'HIGH',
          confidence: 95,
          explanation: 'Prevents you from designing for any web or software client globally for 2 full years.',
          whyFlagged: 'A broad global non-compete for a freelance design contract severely restricts a freelancer\'s core livelihood.',
          whatToCheck: 'Check if non-competes apply to freelancers in your jurisdiction and push to convert to a narrow non-solicitation clause.',
          negotiationSuggestion: '"Can we remove Section 4.1 or narrow it exclusively to direct competitors named in writing?"'
        },
        {
          id: 'free-c3',
          text: '5.1 Unlimited Indemnity: Contractor agrees to defend, indemnify, and hold harmless Client from any and all claims, losses, damages, or legal costs arising out of or related to Contractor\'s work product without monetary cap.',
          category: 'Liability',
          riskLevel: 'HIGH',
          confidence: 93,
          explanation: 'Exposes you to unlimited financial responsibility for any third-party claims or lawsuit costs.',
          whyFlagged: 'Unlimited contractor indemnity without a liability cap creates disproportionate risk compared to project value.',
          whatToCheck: 'Verify whether contractor liability can be capped at total fees paid under the contract.',
          negotiationSuggestion: '"Could we cap Contractor\'s total aggregate liability under Section 5.1 to the total fees actually paid for the project?"'
        },
        {
          id: 'free-c4',
          text: '2.1 Payment Terms: Invoices shall be processed on Net-90 terms from date of client internal approval.',
          category: 'Payment',
          riskLevel: 'HIGH',
          confidence: 91,
          explanation: 'Requires you to wait 90 days after internal client approval before receiving payment.',
          whyFlagged: 'Net-90 + conditional internal approval can delay payment for 4–5 months in practice.',
          whatToCheck: 'Negotiate Net-15 or Net-30 terms measured from invoice date rather than approval date.',
          negotiationSuggestion: '"Can we adjust payment terms in Section 2.1 to Net-30 from invoice submission date?"'
        },
        {
          id: 'free-c5',
          text: '2.2 Unlimited Revisions: Contractor agrees to provide unlimited revisions and layout modifications at no additional charge until Client expresses complete satisfaction.',
          category: 'Service obligations',
          riskLevel: 'MEDIUM',
          confidence: 88,
          explanation: 'Forces you to perform endless revisions without additional payment.',
          whyFlagged: 'Uncapped revisions lead to scope creep and uncompensated labor hours.',
          whatToCheck: 'Define explicit revision rounds included in the fixed fee.',
          negotiationSuggestion: '"Could we specify two (2) rounds of revisions included in the fee, with additional revisions billed at $85/hour?"'
        }
      ]
    }
  },
  {
    id: 'loan-agreement-03',
    title: 'Personal Loan & Promissory Note',
    type: 'Loan / EMI Agreement',
    description: 'Personal loan contract with 36% default interest rate penalty, immediate loan acceleration, and mandatory wage assignment.',
    iconName: 'CreditCard',
    fileSize: '42 KB',
    fullText: `PERSONAL LOAN & PROMISSORY NOTE

Principal Amount: $15,000.00
Borrower: Jane Smith
Lender: Apex Financial Capital Corp

1. REPAYMENT TERMS
1.1 Monthly Payment: Borrower shall repay Principal plus Interest in 36 consecutive monthly installments of $520.00.
1.2 Interest Rate: Standard annual percentage rate (APR) is 14.5% compounded monthly.

2. DEFAULT & PENALTY INTEREST
2.1 Default Rate: If any installment is delayed past 5 calendar days, the APR on the entire remaining principal balance shall automatically escalate to 36.0% per annum ("Penalty Rate").
2.2 Acceleration: Upon a single missed or delayed payment, Lender may declare the entire unpaid principal balance and accrued interest immediately due and payable without notice.

3. SECURITY & WAGE ASSIGNMENT
3.1 Voluntary Wage Assignment: Borrower hereby assigns 25% of Borrower's gross weekly earnings to Lender, authorizing Lender to contact Borrower's employer directly to deduct funds upon payment delay.
3.2 Cross-Collateralization: Borrower pledges all personal property, vehicles, and bank accounts as security for performance under this Note.

4. PREPAYMENT & DISPUTES
4.1 Prepayment Penalty: In the event Borrower pays off the principal early, Borrower shall pay a prepayment fee equal to 10% of the remaining outstanding balance.
4.2 Dispute Forum: Any litigation shall be conducted exclusively in the State Court of Nevada, with Borrower waiving personal jurisdiction objections.`,
    precomputedAnalysis: {
      documentName: 'Personal Loan Note.pdf',
      documentType: 'Promissory Note',
      overallRiskScore: 89,
      riskLevelLabel: 'VERY HIGH REVIEW SIGNAL',
      summary: 'This promissory note contains aggressive consumer loan terms including a 36% default interest spike, single-day loan acceleration, direct employer wage assignment, and a 10% early repayment fee.',
      analyzedAt: new Date().toISOString(),
      isFallback: false,
      disclaimer: 'ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional.',
      recommendations: [
        'Request elimination of the 36% penalty default interest rate.',
        'Remove direct employer wage assignment clauses.',
        'Eliminate the 10% prepayment fee to allow unpenalized early payoff.',
        'Add a mandatory 15-day cure period prior to loan acceleration.'
      ],
      categoryBreakdown: [
        { category: 'Penalty', score: 92, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Liability', score: 88, count: 2, highCount: 2, mediumCount: 0, lowCount: 0 },
        { category: 'Payment', score: 70, count: 2, highCount: 1, mediumCount: 1, lowCount: 0 },
        { category: 'Dispute resolution', score: 50, count: 1, highCount: 0, mediumCount: 1, lowCount: 0 }
      ],
      clauses: [
        {
          id: 'loan-c1',
          text: '2.1 Default Rate: If any installment is delayed past 5 calendar days, the APR on the entire remaining principal balance shall automatically escalate to 36.0% per annum ("Penalty Rate").',
          category: 'Penalty',
          riskLevel: 'HIGH',
          confidence: 98,
          explanation: 'Spikes your interest rate to a steep 36% APR across the entire loan balance if payment is 5 days late.',
          whyFlagged: 'A 36% default rate far exceeds standard APR escalation benchmarks and borderlines usury limits in many states.',
          whatToCheck: 'Check maximum allowable consumer loan default rates in your state.',
          negotiationSuggestion: '"Can we replace the 36% default rate with a flat standard late charge of $25 after 10 days?"'
        },
        {
          id: 'loan-c2',
          text: '3.1 Voluntary Wage Assignment: Borrower hereby assigns 25% of Borrower\'s gross weekly earnings to Lender, authorizing Lender to contact Borrower\'s employer directly to deduct funds upon payment delay.',
          category: 'Liability',
          riskLevel: 'HIGH',
          confidence: 96,
          explanation: 'Grants the lender authority to contact your employer directly and seize 25% of your paycheck without court order.',
          whyFlagged: 'Direct wage assignment bypassing court garnishment orders is prohibited or restricted in many consumer protection jurisdictions.',
          whatToCheck: 'Verify whether non-judicial wage assignments are legal for consumer loans in your home state.',
          negotiationSuggestion: '"Could we strike Section 3.1 (Wage Assignment) in favor of standard bank auto-pay arrangements?"'
        },
        {
          id: 'loan-c3',
          text: '2.2 Acceleration: Upon a single missed or delayed payment, Lender may declare the entire unpaid principal balance and accrued interest immediately due and payable without notice.',
          category: 'Penalty',
          riskLevel: 'HIGH',
          confidence: 95,
          explanation: 'Demands full payment of the entire $15,000 loan immediately after missing a single monthly payment.',
          whyFlagged: 'Immediate acceleration without a written notice and cure period (typically 15-30 days) is predatory.',
          whatToCheck: 'Negotiate a mandatory 15 or 30-day written notice to cure default prior to acceleration.',
          negotiationSuggestion: '"Can we add a requirement for 15 calendar days written notice to cure any default before acceleration occurs?"'
        },
        {
          id: 'loan-c4',
          text: '4.1 Prepayment Penalty: In the event Borrower pays off the principal early, Borrower shall pay a prepayment fee equal to 10% of the remaining outstanding balance.',
          category: 'Payment',
          riskLevel: 'HIGH',
          confidence: 92,
          explanation: 'Penalizes you with a 10% fine if you try to pay off the loan early to save on interest.',
          whyFlagged: 'Modern consumer loans generally allow fee-free early repayment.',
          whatToCheck: 'Request complete removal of prepayment penalties.',
          negotiationSuggestion: '"Could we remove Section 4.1 so Borrower may prepay Principal at any time without penalty?"'
        }
      ]
    }
  }
];
