export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export type RiskCategory =
  | 'Payment'
  | 'Termination'
  | 'Penalty'
  | 'Liability'
  | 'Renewal'
  | 'Privacy'
  | 'Data usage'
  | 'Deposit'
  | 'Notice period'
  | 'Dispute resolution'
  | 'Non-compete'
  | 'Intellectual property'
  | 'Confidentiality'
  | 'Service obligations'
  | 'Other';

export interface Clause {
  id: string;
  text: string;
  category: RiskCategory;
  riskLevel: RiskLevel;
  confidence: number; // 0 - 100
  explanation: string;
  whyFlagged: string;
  whatToCheck: string;
  negotiationSuggestion: string;
}

export interface CategoryBreakdownItem {
  category: RiskCategory;
  score: number; // 0 - 100 risk density
  count: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
}

export interface AnalysisResult {
  documentName: string;
  documentType: string;
  overallRiskScore: number; // 0 - 100
  riskLevelLabel: 'LOW REVIEW SIGNAL' | 'MODERATE REVIEW SIGNAL' | 'HIGH REVIEW SIGNAL' | 'VERY HIGH REVIEW SIGNAL';
  summary: string;
  clauses: Clause[];
  categoryBreakdown: CategoryBreakdownItem[];
  recommendations: string[];
  disclaimer: string;
  analyzedAt: string;
  isFallback?: boolean;
}

export interface DemoContract {
  id: string;
  title: string;
  type: string;
  description: string;
  iconName: string;
  fileSize: string;
  fullText: string;
  precomputedAnalysis: AnalysisResult;
}
