import React from 'react';
import { ShieldAlert, FileText, Zap, Sparkles, ArrowRight, RotateCcw } from 'lucide-react';

interface NavbarProps {
  onOpenUpload: () => void;
  onLaunchJudgeDemo: () => void;
  hasActiveAnalysis: boolean;
  onReset: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenUpload,
  onLaunchJudgeDemo,
  hasActiveAnalysis,
  onReset,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0A0A0A]/90 backdrop-blur-md border-b border-[#222222] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={onReset}>
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-[#CCFF00] p-[1px] shadow-lg shadow-[#CCFF00]/10">
            <div className="w-full h-full bg-[#0A0A0A] rounded-[11px] flex items-center justify-center">
              <span className="text-xl font-black tracking-widest text-[#CCFF00]">
                CX
              </span>
            </div>
            {/* Pulsing neon status accent */}
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#CCFF00] rounded-full animate-ping opacity-75" />
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#CCFF00] rounded-full" />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xl font-black tracking-widest text-[#F0F0F0] uppercase font-mono">
                Clause<span className="text-[#CCFF00]">X</span>
              </span>
              <span className="text-[10px] uppercase font-mono font-bold tracking-[0.2em] px-2 py-0.5 rounded bg-[#CCFF00]/10 border border-[#CCFF00]/30 text-[#CCFF00]">
                AI X-RAY
              </span>
            </div>
            <p className="text-[11px] text-[#888888] font-mono uppercase tracking-wider hidden sm:block">
              Visual Risk Inspection for Contracts
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {hasActiveAnalysis ? (
            <>
              <button
                onClick={onReset}
                className="px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-mono uppercase tracking-wider text-[#F0F0F0] bg-[#141414] border border-[#222222] hover:bg-[#1f1f1f] transition flex items-center space-x-1.5"
                id="btn-new-analysis"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#888888]" />
                <span>New Contract</span>
              </button>
            </>
          ) : null}

          {/* JUDGE DEMO MODE BUTTON */}
          <button
            onClick={onLaunchJudgeDemo}
            className="group relative px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-mono font-bold uppercase tracking-wider text-black bg-[#CCFF00] hover:bg-[#b8e600] transition shadow-md shadow-[#CCFF00]/20 flex items-center space-x-2 border border-[#CCFF00] overflow-hidden"
            id="btn-launch-judge-demo"
            title="Run 60-second instant judge demo"
          >
            <div className="absolute inset-0 w-1/2 h-full bg-white/30 skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000" />
            <Zap className="w-4 h-4 text-black fill-black" />
            <span className="font-extrabold tracking-widest">Launch Demo</span>
            <span className="hidden md:inline-block text-[10px] bg-black/20 px-1.5 py-0.5 rounded text-black font-mono border border-black/20">
              60s
            </span>
          </button>

          {!hasActiveAnalysis && (
            <button
              onClick={onOpenUpload}
              className="px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-mono font-semibold uppercase tracking-wider text-[#F0F0F0] bg-[#141414] border border-[#333333] hover:bg-[#1f1f1f] hover:border-[#CCFF00]/50 transition flex items-center space-x-2"
              id="btn-upload-contract-nav"
            >
              <FileText className="w-4 h-4 text-[#CCFF00]" />
              <span>Upload File</span>
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
