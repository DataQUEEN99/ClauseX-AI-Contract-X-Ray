import React, { useEffect, useState } from 'react';
import { SearchCode, CheckCircle2, Loader2, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';

interface ProcessingSequenceProps {
  filename: string;
  isReady?: boolean;
  onComplete: () => void;
  onFallbackToDemo?: () => void;
  error?: string | null;
}

const STEPS = [
  { id: '01', title: 'Reading document & extracting text structure', desc: 'Parsing sections, paragraph boundaries, and clauses' },
  { id: '02', title: 'Detecting clauses & legal obligations', desc: 'Isolating payment, termination, penalty, and liability terms' },
  { id: '03', title: 'Checking unusual terms vs reference patterns', desc: 'Cross-referencing clause provisions against fair benchmark patterns' },
  { id: '04', title: 'Evaluating risk severity & confidence scores', desc: 'Applying deterministic risk metrics (0–100) per clause' },
  { id: '05', title: 'Generating plain-language guides & negotiation phrasing', desc: 'Formulating practical questions and ready-to-use email phrasing' },
  { id: '06', title: 'Building visual Contract X-Ray map', desc: 'Synthesizing color-coded clause highlights and diagnostic panel' }
];

export const ProcessingSequence: React.FC<ProcessingSequenceProps> = ({
  filename,
  isReady = true,
  onComplete,
  onFallbackToDemo,
  error,
}) => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (error) return;

    // Step progress interval animation
    const totalDuration = 4000; // ~4 seconds for complete sequence
    const intervalTime = 100;
    const stepIncrement = (100 / (totalDuration / intervalTime));

    const timer = setInterval(() => {
      setProgress((prev) => {
        let next = prev + stepIncrement;

        // Hold at 95% if analysis is still pending on server
        if (next >= 95 && !isReady) {
          next = 95;
        }

        if (next >= 100 && isReady) {
          clearInterval(timer);
          setTimeout(() => {
            onComplete();
          }, 300);
          return 100;
        }

        // Map progress percentage to active step index (0 to 5)
        const computedStep = Math.min(5, Math.floor((next / 100) * 6));
        setActiveStepIndex(computedStep);

        return next;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [error, isReady, onComplete]);

  return (
    <div className="max-w-3xl mx-auto px-4 py-16 animate-fade-in">
      <div className="bg-[#111111] border border-[#222222] rounded-3xl p-8 sm:p-10 shadow-2xl space-y-8 relative overflow-hidden text-[#F0F0F0]">
        
        {/* Top Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-[#CCFF00] text-xs font-mono font-bold uppercase tracking-[0.2em]">
            <Sparkles className="w-3.5 h-3.5 text-[#CCFF00] animate-pulse" />
            <span>AI X-RAY IN PROGRESS</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-[#F0F0F0] uppercase tracking-tight">
            Inspecting Document
          </h2>
          <p className="text-sm text-[#888888] font-mono">
            {filename || 'Contract_Document.pdf'}
          </p>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono text-[#888888]">
            <span className="uppercase tracking-widest font-bold">ANALYSIS PROGRESS</span>
            <span className="text-[#CCFF00] font-bold">{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-3 bg-[#0A0A0A] rounded-full overflow-hidden border border-[#222222] p-0.5">
            <div
              className="h-full bg-[#CCFF00] rounded-full transition-all duration-150"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Error Handling State */}
        {error ? (
          <div className="p-6 rounded-2xl bg-red-950/80 border border-red-800 text-[#F0F0F0] space-y-4">
            <div className="flex items-center space-x-3 text-red-400 font-mono font-bold text-base uppercase">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <span>Live AI Analysis Unavailable</span>
            </div>
            <p className="text-xs text-[#888888] font-mono leading-relaxed">
              {error}
            </p>
            {onFallbackToDemo && (
              <div className="pt-2">
                <button
                  onClick={onFallbackToDemo}
                  className="px-5 py-3 rounded-xl bg-[#CCFF00] text-black font-mono font-bold text-xs uppercase tracking-wider hover:bg-[#b8e600] transition flex items-center space-x-2 shadow-lg"
                  id="btn-fallback-demo"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  <span>Continue with Demo Analysis</span>
                  <ArrowRight className="w-4 h-4 text-black" />
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Steps Sequence Timeline */
          <div className="space-y-3 pt-2">
            {STEPS.map((step, idx) => {
              const isDone = idx < activeStepIndex || progress === 100;
              const isCurrent = idx === activeStepIndex && progress < 100;

              return (
                <div
                  key={step.id}
                  className={`p-3.5 rounded-xl border transition-all flex items-center space-x-4 ${
                    isDone
                      ? 'bg-[#0A0A0A] border-[#222222] text-[#888888]'
                      : isCurrent
                      ? 'bg-[#0A0A0A] border-[#CCFF00] text-[#F0F0F0] shadow-lg'
                      : 'bg-[#0A0A0A]/40 border-[#1a1a1a] text-[#888888]/50'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                      isDone
                        ? 'bg-[#CCFF00]/10 border border-[#CCFF00]/30 text-[#CCFF00]'
                        : isCurrent
                        ? 'bg-[#CCFF00] text-black'
                        : 'bg-[#141414] border border-[#222222] text-[#888888]'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-[#CCFF00]" />
                    ) : isCurrent ? (
                      <Loader2 className="w-4 h-4 text-black animate-spin" />
                    ) : (
                      <span>{step.id}</span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className={`text-xs font-bold font-mono uppercase ${isCurrent ? 'text-[#CCFF00]' : isDone ? 'text-[#F0F0F0]' : 'text-[#888888]'}`}>
                      {step.title}
                    </h4>
                    <p className="text-[11px] text-[#888888] font-mono truncate">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
};
