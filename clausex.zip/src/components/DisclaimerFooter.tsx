import React from 'react';
import { Scale, Lock, ShieldCheck } from 'lucide-react';

export const DisclaimerFooter: React.FC = () => {
  return (
    <footer className="bg-[#0A0A0A] border-t border-[#222222] py-8 text-[#888888] text-xs font-mono">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4 text-center sm:text-left">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="font-black text-[#F0F0F0] font-mono text-sm uppercase">
              Clause<span className="text-[#CCFF00]">X</span>
            </span>
            <span className="text-[10px] text-[#888888] font-mono uppercase tracking-widest">| AI X-RAY FOR CONTRACTS</span>
          </div>

          <div className="flex items-center space-x-4 text-[11px] text-[#888888] uppercase">
            <span className="flex items-center space-x-1">
              <Lock className="w-3 h-3 text-[#CCFF00]" />
              <span>In-Memory Processing</span>
            </span>
            <span>•</span>
            <span className="flex items-center space-x-1">
              <ShieldCheck className="w-3 h-3 text-[#CCFF00]" />
              <span>Decision Support</span>
            </span>
          </div>
        </div>

        <div className="pt-3 border-t border-[#1a1a1a] text-[11px] text-[#888888] font-mono leading-relaxed uppercase">
          <strong className="text-[#F0F0F0]">LEGAL POSITIONING & DISCLAIMER:</strong> ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional. ClauseX does not state or guarantee legal outcomes or invalidity of contract terms.
        </div>
      </div>
    </footer>
  );
};
