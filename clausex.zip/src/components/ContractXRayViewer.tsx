import React, { useState } from 'react';
import {
  Search,
  Filter,
  AlertTriangle,
  Info,
  CheckCircle2,
  Copy,
  Check,
  ShieldAlert,
  Sparkles,
  HelpCircle,
  FileText,
  MessageSquareText,
  ChevronRight
} from 'lucide-react';
import { Clause, RiskLevel, RiskCategory } from '../types/contract';

interface ContractXRayViewerProps {
  documentName: string;
  documentType: string;
  clauses: Clause[];
  fullText?: string;
}

export const ContractXRayViewer: React.FC<ContractXRayViewerProps> = ({
  documentName,
  documentType,
  clauses,
  fullText,
}) => {
  const [selectedClauseId, setSelectedClauseId] = useState<string>(clauses[0]?.id || '');
  const [filterLevel, setFilterLevel] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Selected clause calculation
  const selectedClause = clauses.find((c) => c.id === selectedClauseId) || clauses[0];

  // Filter clauses
  const filteredClauses = clauses.filter((c) => {
    const matchesFilter = filterLevel === 'ALL' || c.riskLevel === filterLevel;
    const matchesSearch =
      searchQuery.trim() === '' ||
      c.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.explanation.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // Copy negotiation suggestion helper
  const handleCopySuggestion = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Get risk styling
  const getRiskBadge = (level: RiskLevel) => {
    if (level === 'HIGH') {
      return {
        label: 'HIGH CONCERN',
        bg: 'bg-red-500/10',
        text: 'text-red-400',
        border: 'border-red-500/40',
        ring: 'ring-red-500/30',
        highlightBg: 'bg-[#0A0A0A] border border-red-900/60 text-red-100 hover:border-red-500',
        activeHighlightBg: 'bg-[#0A0A0A] border-2 border-red-500 shadow-2xl text-white',
        icon: <AlertTriangle className="w-3.5 h-3.5 text-red-400" />,
      };
    }
    if (level === 'MEDIUM') {
      return {
        label: 'REVIEW',
        bg: 'bg-amber-500/10',
        text: 'text-amber-400',
        border: 'border-amber-500/40',
        ring: 'ring-amber-500/30',
        highlightBg: 'bg-[#0A0A0A] border border-amber-900/60 text-amber-100 hover:border-amber-500',
        activeHighlightBg: 'bg-[#0A0A0A] border-2 border-amber-500 shadow-2xl text-white',
        icon: <Info className="w-3.5 h-3.5 text-amber-400" />,
      };
    }
    return {
      label: 'LOW CONCERN',
      bg: 'bg-[#CCFF00]/10',
      text: 'text-[#CCFF00]',
      border: 'border-[#CCFF00]/30',
      ring: 'ring-[#CCFF00]/30',
      highlightBg: 'bg-[#0A0A0A] border border-[#222222] text-[#F0F0F0] hover:border-[#CCFF00]/50',
      activeHighlightBg: 'bg-[#0A0A0A] border-2 border-[#CCFF00] shadow-2xl text-white',
      icon: <CheckCircle2 className="w-3.5 h-3.5 text-[#CCFF00]" />,
    };
  };

  const highCount = clauses.filter((c) => c.riskLevel === 'HIGH').length;
  const mediumCount = clauses.filter((c) => c.riskLevel === 'MEDIUM').length;
  const lowCount = clauses.filter((c) => c.riskLevel === 'LOW').length;

  return (
    <div className="space-y-6">
      
      {/* Search & Risk Filter Toolbar */}
      <div className="bg-[#111111] border border-[#222222] rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        
        {/* Document Metadata Pill */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00]">
            <FileText className="w-5 h-5 text-[#CCFF00]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#F0F0F0] flex items-center space-x-2">
              <span>{documentName}</span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#141414] text-[#888888] border border-[#222222] uppercase">
                {documentType}
              </span>
            </h3>
            <p className="text-xs font-mono text-[#888888]">
              Visual X-Ray Map ({clauses.length} clauses detected)
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Search Box */}
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-3.5 h-3.5 text-[#888888] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search clause text..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#222222] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#F0F0F0] font-mono focus:outline-none focus:border-[#CCFF00] transition"
            />
          </div>

          {/* Level Filter Buttons */}
          <div className="flex items-center bg-[#0A0A0A] p-1 rounded-lg border border-[#222222] text-xs font-mono">
            <button
              onClick={() => setFilterLevel('ALL')}
              className={`px-2.5 py-1 rounded-md font-bold transition uppercase ${
                filterLevel === 'ALL'
                  ? 'bg-[#CCFF00] text-black'
                  : 'text-[#888888] hover:text-[#F0F0F0]'
              }`}
            >
              All ({clauses.length})
            </button>
            <button
              onClick={() => setFilterLevel('HIGH')}
              className={`px-2.5 py-1 rounded-md font-bold transition flex items-center space-x-1 uppercase ${
                filterLevel === 'HIGH'
                  ? 'bg-red-950 text-red-300 border border-red-800'
                  : 'text-red-400/80 hover:text-red-300'
              }`}
            >
              <span>High</span>
              <span className="bg-red-900/60 text-red-200 px-1 rounded text-[10px] font-mono">{highCount}</span>
            </button>
            <button
              onClick={() => setFilterLevel('MEDIUM')}
              className={`px-2.5 py-1 rounded-md font-bold transition flex items-center space-x-1 uppercase ${
                filterLevel === 'MEDIUM'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              <span>Review</span>
              <span className="bg-amber-900/60 text-amber-200 px-1 rounded text-[10px] font-mono">{mediumCount}</span>
            </button>
            <button
              onClick={() => setFilterLevel('LOW')}
              className={`px-2.5 py-1 rounded-md font-bold transition flex items-center space-x-1 uppercase ${
                filterLevel === 'LOW'
                  ? 'bg-[#CCFF00]/20 text-[#CCFF00] border border-[#CCFF00]/40'
                  : 'text-[#CCFF00]/80 hover:text-[#CCFF00]'
              }`}
            >
              <span>Low</span>
              <span className="bg-[#CCFF00]/20 text-[#CCFF00] px-1 rounded text-[10px] font-mono">{lowCount}</span>
            </button>
          </div>

        </div>

      </div>

      {/* Main Grid: Left Readable Document View + Right Clause Inspection Panel */}
      <div className="grid lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column (7 cols): Document X-Ray View */}
        <div className="lg:col-span-7 bg-[#111111] border border-[#222222] rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#222222]">
            <span className="text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-[0.15em] flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#CCFF00]" />
              <span>CONTRACT DOCUMENT X-RAY</span>
            </span>
            <span className="text-[11px] text-[#888888] font-mono uppercase tracking-wider">Click clause to inspect</span>
          </div>

          <div className="space-y-3 max-h-[680px] overflow-y-auto pr-1">
            {filteredClauses.length === 0 ? (
              <div className="text-center py-12 text-[#888888] space-y-2 font-mono">
                <Search className="w-8 h-8 mx-auto text-[#888888]" />
                <p className="text-xs">
                  {clauses.length === 0
                    ? 'No risk-flagged clauses detected in this document.'
                    : 'No clauses match your current filter query.'}
                </p>
              </div>
            ) : (
              filteredClauses.map((clause) => {
                const badge = getRiskBadge(clause.riskLevel);
                const isSelected = selectedClause?.id === clause.id;

                return (
                  <div
                    key={clause.id}
                    onClick={() => setSelectedClauseId(clause.id)}
                    className={`p-4 rounded-2xl transition-all cursor-pointer relative ${
                      isSelected ? badge.activeHighlightBg : badge.highlightBg
                    }`}
                    id={`clause-card-${clause.id}`}
                  >
                    {/* Clause Header */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider uppercase border ${badge.bg} ${badge.text} ${badge.border}`}>
                          {badge.icon}
                          <span>{badge.label}</span>
                        </span>
                        <span className="text-[11px] font-mono font-bold text-[#F0F0F0] bg-[#141414] px-2 py-0.5 rounded border border-[#222222] uppercase">
                          {clause.category}
                        </span>
                      </div>

                      <div className="flex items-center space-x-2 text-[10px] font-mono text-[#888888]">
                        <span>{clause.confidence}% Confidence</span>
                        <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isSelected ? 'translate-x-1 text-[#CCFF00]' : ''}`} />
                      </div>
                    </div>

                    {/* Direct Clause Text Quote */}
                    <p className="text-xs sm:text-sm leading-relaxed text-[#F0F0F0] font-mono">
                      "{clause.text}"
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column (5 cols): Selected Clause Inspector Panel */}
        <div className="lg:col-span-5 sticky top-20">
          {selectedClause ? (
            <div className="bg-[#111111] border border-[#222222] rounded-3xl p-6 shadow-2xl space-y-5">
              
              {/* Header */}
              <div className="pb-4 border-b border-[#222222] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-[0.15em] flex items-center space-x-1.5">
                    <ShieldAlert className="w-4 h-4 text-[#CCFF00]" />
                    <span>CLAUSE DIAGNOSTIC PANEL</span>
                  </span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#0A0A0A] border border-[#222222] text-[#888888]">
                    ID: {selectedClause.id}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  {(() => {
                    const badge = getRiskBadge(selectedClause.riskLevel);
                    return (
                      <span className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-mono font-bold tracking-wide uppercase border ${badge.bg} ${badge.text} ${badge.border}`}>
                        {badge.icon}
                        <span>{badge.label}</span>
                      </span>
                    );
                  })()}
                  <span className="text-xs font-mono font-bold text-[#F0F0F0] bg-[#0A0A0A] px-2.5 py-1 rounded-md border border-[#222222] uppercase">
                    Category: {selectedClause.category}
                  </span>
                </div>
              </div>

              {/* Clause Direct Quote */}
              <div className="bg-[#0A0A0A] p-3.5 rounded-xl border border-[#222222] space-y-1">
                <span className="text-[10px] font-mono text-[#888888] uppercase tracking-wider block">
                  SELECTED CLAUSE TEXT:
                </span>
                <p className="text-xs font-mono text-[#F0F0F0] leading-relaxed italic">
                  "{selectedClause.text}"
                </p>
              </div>

              {/* Plain Language Explanation */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono font-bold text-[#F0F0F0] uppercase tracking-wider flex items-center space-x-1.5">
                  <Info className="w-3.5 h-3.5 text-[#CCFF00]" />
                  <span>PLAIN-LANGUAGE EXPLANATION</span>
                </h4>
                <p className="text-xs text-[#F0F0F0] leading-relaxed bg-[#0A0A0A] p-3 rounded-xl border border-[#222222]">
                  {selectedClause.explanation}
                </p>
              </div>

              {/* Why Flagged */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>WHY CLAUSEX FLAGGED IT</span>
                </h4>
                <p className="text-xs text-[#F0F0F0] leading-relaxed bg-amber-950/20 p-3 rounded-xl border border-amber-900/40">
                  {selectedClause.whyFlagged}
                </p>
              </div>

              {/* What To Check */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-mono font-bold text-blue-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                  <span>WHAT TO CHECK & VERIFY</span>
                </h4>
                <p className="text-xs text-[#F0F0F0] leading-relaxed bg-[#0A0A0A] p-3 rounded-xl border border-[#222222]">
                  {selectedClause.whatToCheck}
                </p>
              </div>

              {/* Negotiation Suggestion & Copy Button */}
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-wider flex items-center space-x-1.5">
                    <MessageSquareText className="w-3.5 h-3.5 text-[#CCFF00]" />
                    <span>POSSIBLE NEGOTIATION SUGGESTION</span>
                  </h4>
                  <button
                    onClick={() => handleCopySuggestion(selectedClause.negotiationSuggestion, selectedClause.id)}
                    className="text-[11px] font-mono font-bold text-black bg-[#CCFF00] hover:bg-[#b8e600] border border-[#CCFF00] px-2.5 py-1 rounded flex items-center space-x-1 transition uppercase"
                    id={`btn-copy-negotiation-${selectedClause.id}`}
                  >
                    {copiedId === selectedClause.id ? (
                      <>
                        <Check className="w-3 h-3 text-black" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-black" />
                        <span>Copy Wording</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-[#0A0A0A] p-3.5 rounded-xl border border-[#222222] text-xs text-[#F0F0F0] font-mono leading-relaxed">
                  {selectedClause.negotiationSuggestion}
                </div>
              </div>

              {/* Disclaimer Note */}
              <div className="pt-2 border-t border-[#222222]">
                <p className="text-[10px] font-mono text-[#888888] leading-tight">
                  ℹ️ ClauseX provides educational decision support. Review specific clauses with a qualified legal professional prior to signing.
                </p>
              </div>

            </div>
          ) : (
            <div className="bg-[#111111] border border-[#222222] rounded-3xl p-8 text-center text-[#888888] font-mono text-xs">
              Select a clause from the X-Ray document view on the left to inspect detailed risk analysis.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
