import React, { useState, useRef } from 'react';
import { Upload, FileText, X, Sparkles, CheckCircle2, AlertCircle, Home, Briefcase, CreditCard, ArrowRight } from 'lucide-react';
import { DEMO_CONTRACTS } from '../data/demoContracts';
import { DemoContract } from '../types/contract';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectFile: (file: File) => void;
  onSelectDemo: (demo: DemoContract) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onSelectFile,
  onSelectDemo,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    setErrorMsg(null);
    if (!file) return;

    // Check empty file
    if (file.size === 0) {
      setErrorMsg('The selected file is empty (0 bytes). Please upload a valid contract file.');
      return;
    }

    // Check size limit (e.g. 15MB)
    if (file.size > 15 * 1024 * 1024) {
      setErrorMsg('File size exceeds 15MB. Please upload a smaller document for optimal performance.');
      return;
    }

    // Check extension / type
    const name = file.name.toLowerCase();
    const isPdf = name.endsWith('.pdf') || file.type === 'application/pdf';
    const isTxt = name.endsWith('.txt') || file.type.startsWith('text/');

    if (!isPdf && !isTxt) {
      setErrorMsg('Please upload a PDF (.pdf) or Plain Text (.txt) contract file.');
      return;
    }

    onSelectFile(file);
    onClose();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      
      {/* Modal Card */}
      <div className="relative w-full max-w-2xl bg-[#111111] border border-[#222222] rounded-3xl shadow-2xl p-6 sm:p-8 space-y-6 overflow-hidden text-[#F0F0F0]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-[#888888] hover:text-[#F0F0F0] bg-[#141414] hover:bg-[#222222] border border-[#222222] transition"
          id="btn-close-upload-modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-[#CCFF00] text-xs font-mono font-bold uppercase tracking-[0.2em] mb-2">
            <Upload className="w-3.5 h-3.5 text-[#CCFF00]" />
            <span>CONTRACT ANALYSIS INTAKE</span>
          </div>
          <h2 className="text-2xl font-black text-[#F0F0F0] uppercase tracking-tight">
            Upload Contract File
          </h2>
          <p className="text-[#888888] text-sm font-mono">
            Select your contract document or launch one of our built-in synthetic demo contracts.
          </p>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-950/80 border border-red-800 text-red-200 text-xs font-mono flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Drag & Drop Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-[#CCFF00] bg-[#CCFF00]/10 scale-[1.01]'
              : 'border-[#333333] bg-[#0A0A0A] hover:border-[#CCFF00] hover:bg-[#0D0D0D]'
          }`}
          id="dropzone-contract"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.txt,application/pdf,text/plain"
            onChange={handleFileChange}
            className="hidden"
          />

          <div className="flex flex-col items-center justify-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00] shadow-inner">
              <Upload className="w-7 h-7 text-[#CCFF00]" />
            </div>

            <div>
              <p className="text-base font-bold text-[#F0F0F0]">
                Drop your contract here, or <span className="text-[#CCFF00] underline decoration-[#CCFF00]/50">browse files</span>
              </p>
              <p className="text-xs font-mono text-[#888888] mt-1">
                Supports PDF (.pdf) or Text (.txt) up to 15MB
              </p>
            </div>

            <div className="flex items-center space-x-3 text-[11px] font-mono text-[#888888] pt-1 uppercase">
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-3 h-3 text-[#CCFF00]" />
                <span>In-Memory Security</span>
              </span>
              <span>•</span>
              <span>Confidential Processing</span>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="relative flex items-center justify-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-[#222222]" />
          </div>
          <span className="relative px-4 bg-[#111111] text-xs font-bold text-[#888888] uppercase tracking-[0.15em] font-mono">
            OR TRY A BUILT-IN DEMO CONTRACT
          </span>
        </div>

        {/* Demo Contracts Selection */}
        <div className="grid sm:grid-cols-3 gap-3">
          {DEMO_CONTRACTS.map((demo) => {
            const getIcon = () => {
              if (demo.iconName === 'Home') return <Home className="w-4 h-4 text-[#CCFF00]" />;
              if (demo.iconName === 'Briefcase') return <Briefcase className="w-4 h-4 text-[#CCFF00]" />;
              return <CreditCard className="w-4 h-4 text-[#CCFF00]" />;
            };

            return (
              <button
                key={demo.id}
                onClick={() => {
                  onSelectDemo(demo);
                  onClose();
                }}
                className="p-3.5 rounded-xl bg-[#0A0A0A] border border-[#222222] hover:border-[#CCFF00] hover:bg-[#141414] text-left transition group space-y-2"
                id={`btn-demo-select-${demo.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="p-1.5 rounded-lg bg-[#141414] border border-[#222222]">
                    {getIcon()}
                  </div>
                  <span className="text-[10px] font-mono font-bold text-[#888888] group-hover:text-[#CCFF00] flex items-center space-x-0.5 uppercase">
                    <span>Try</span>
                    <ArrowRight className="w-2.5 h-2.5 ml-0.5" />
                  </span>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-[#F0F0F0] font-mono uppercase group-hover:text-[#CCFF00] transition">
                    {demo.title}
                  </h4>
                  <p className="text-[11px] text-[#888888] line-clamp-2 mt-0.5">
                    {demo.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </div>
  );
};
