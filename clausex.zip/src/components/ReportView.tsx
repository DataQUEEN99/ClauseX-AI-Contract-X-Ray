import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Printer, Download, X, ShieldAlert, CheckCircle2, AlertTriangle, Sparkles } from 'lucide-react';
import { AnalysisResult } from '../types/contract';

interface ReportViewProps {
  analysis: AnalysisResult;
  onClose: () => void;
}

export const ReportView: React.FC<ReportViewProps> = ({ analysis, onClose }) => {
  useEffect(() => {
    // Confetti burst on report opening
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#CCFF00', '#ffffff', '#222222', '#888888'],
      });
    } catch (e) {
      // ignore
    }
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const highClauses = analysis.clauses.filter((c) => c.riskLevel === 'HIGH');
  const mediumClauses = analysis.clauses.filter((c) => c.riskLevel === 'MEDIUM');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md p-4 sm:p-6 lg:p-8 animate-fade-in text-[#F0F0F0]">
      
      {/* Top Action Bar */}
      <div className="max-w-4xl mx-auto mb-4 flex items-center justify-between bg-[#111111] border border-[#222222] rounded-2xl p-4 shadow-xl print:hidden">
        <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-[0.15em]">
          <Sparkles className="w-4 h-4 text-[#CCFF00]" />
          <span>CLAUSEX SUMMARY REPORT GENERATOR</span>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl bg-[#CCFF00] hover:bg-[#b8e600] text-black font-mono font-bold text-xs uppercase tracking-wider transition flex items-center space-x-2 shadow-lg"
            id="btn-print-report"
          >
            <Printer className="w-4 h-4 text-black" />
            <span>Print or Save as PDF</span>
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#888888] hover:text-[#F0F0F0] bg-[#141414] hover:bg-[#222222] border border-[#222222] transition"
            id="btn-close-report"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="max-w-4xl mx-auto bg-[#111111] border border-[#222222] rounded-3xl p-8 sm:p-12 shadow-2xl text-[#F0F0F0] space-y-8 print:bg-white print:text-slate-900 print:border-none print:shadow-none print:p-0">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-[#222222] print:border-slate-300">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#CCFF00] border border-[#CCFF00] flex items-center justify-center text-black font-black font-mono text-xl print:border-black">
              CX
            </div>
            <div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-[#F0F0F0] print:text-slate-900 font-mono">
                Clause<span className="text-[#CCFF00]">X</span> Analysis Report
              </h1>
              <p className="text-xs font-mono text-[#888888] print:text-slate-600">
                Visual Risk Inspection & Decision Support
              </p>
            </div>
          </div>

          <div className="text-right text-xs font-mono text-[#888888] print:text-slate-600 space-y-0.5 uppercase">
            <p>Date: {new Date(analysis.analyzedAt).toLocaleDateString()}</p>
            <p className="font-bold text-[#F0F0F0] print:text-slate-900">{analysis.documentName}</p>
          </div>
        </div>

        {/* Overall Score Box */}
        <div className="bg-[#0A0A0A] print:bg-slate-50 p-6 rounded-2xl border border-[#222222] print:border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-xs font-mono font-bold text-[#888888] print:text-slate-600 uppercase tracking-widest">
              DOCUMENT TYPE: {analysis.documentType}
            </span>
            <h2 className="text-xl font-black uppercase text-[#F0F0F0] print:text-slate-900 font-mono">
              Overall Risk Assessment
            </h2>
            <p className="text-xs text-[#888888] print:text-slate-600 max-w-md">
              {analysis.summary}
            </p>
          </div>

          <div className="text-center sm:text-right shrink-0 bg-[#141414] print:bg-white p-4 rounded-xl border border-[#222222] print:border-slate-200 min-w-[160px]">
            <span className="text-3xl font-black font-mono text-[#CCFF00] print:text-black block">
              {analysis.overallRiskScore} <span className="text-sm text-[#888888]">/ 100</span>
            </span>
            <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-amber-400 print:text-amber-600">
              {analysis.riskLevelLabel}
            </span>
          </div>
        </div>

        {/* Recommended Action Plan */}
        {analysis.recommendations && analysis.recommendations.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-xs font-mono font-bold text-[#CCFF00] print:text-black uppercase tracking-[0.15em]">
              KEY RECOMMENDATIONS BEFORE SIGNING
            </h3>
            <ul className="grid sm:grid-cols-2 gap-3 text-xs font-mono">
              {analysis.recommendations.map((rec, i) => (
                <li key={i} className="bg-[#0A0A0A] print:bg-slate-100 p-3 rounded-xl border border-[#222222] print:border-slate-300 flex items-start space-x-2">
                  <span className="text-[#CCFF00] print:text-black font-bold font-mono">0{i + 1}.</span>
                  <span className="text-[#F0F0F0] print:text-slate-800">{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Flagged High Risk Clauses Section */}
        <div className="space-y-4">
          <h3 className="text-xs font-mono font-bold text-red-400 print:text-red-700 uppercase tracking-[0.15em] flex items-center space-x-1.5">
            <AlertTriangle className="w-4 h-4 text-red-400 print:text-red-600" />
            <span>TOP FLAGGED CLAUSES ({highClauses.length + mediumClauses.length} ITEMS)</span>
          </h3>

          <div className="space-y-4">
            {analysis.clauses.map((clause, idx) => (
              <div
                key={clause.id}
                className="p-4 rounded-2xl bg-[#0A0A0A] print:bg-slate-50 border border-[#222222] print:border-slate-300 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between font-mono">
                  <span className="font-bold text-[#F0F0F0] print:text-slate-900 uppercase">
                    #{idx + 1} {clause.category}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                    clause.riskLevel === 'HIGH' ? 'bg-red-950 text-red-300 print:bg-red-100 print:text-red-800' : 'bg-amber-950 text-amber-300 print:bg-amber-100 print:text-amber-800'
                  }`}>
                    {clause.riskLevel} CONCERN
                  </span>
                </div>

                <p className="font-mono italic text-[#888888] print:text-slate-700">
                  "{clause.text}"
                </p>

                <div className="pt-2 grid sm:grid-cols-2 gap-2 text-[11px] font-mono">
                  <div>
                    <strong className="text-[#888888] print:text-slate-600 block uppercase">Explanation:</strong>
                    <span className="text-[#F0F0F0] print:text-slate-800">{clause.explanation}</span>
                  </div>
                  <div>
                    <strong className="text-[#CCFF00] print:text-emerald-700 block uppercase">Suggested Negotiation:</strong>
                    <span className="text-[#F0F0F0] print:text-emerald-900">{clause.negotiationSuggestion}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Legal Disclaimer Footer */}
        <div className="pt-6 border-t border-[#222222] print:border-slate-300 text-center text-[10px] text-[#888888] print:text-slate-600 font-mono uppercase tracking-wider leading-relaxed">
          <p>
            <strong>LEGAL DISCLAIMER:</strong> {analysis.disclaimer}
          </p>
          <p className="mt-1 font-bold text-[#F0F0F0]">
            Generated by ClauseX AI Contract Inspection System.
          </p>
        </div>

      </div>

    </div>
  );
};
