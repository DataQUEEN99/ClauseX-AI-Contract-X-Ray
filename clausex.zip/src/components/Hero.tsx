import React, { useState } from 'react';
import { FileText, ShieldAlert, Zap, ArrowRight, CheckCircle2, AlertTriangle, Info, Search } from 'lucide-react';

interface HeroProps {
  onOpenUpload: () => void;
  onLaunchDemo: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenUpload, onLaunchDemo }) => {
  const [activeHighlight, setActiveHighlight] = useState<'red' | 'amber' | 'green'>('red');

  return (
    <section className="relative overflow-hidden pt-10 pb-16 lg:pt-16 lg:pb-24 bg-[#0A0A0A] text-[#F0F0F0]">
      {/* Background Grid & Border Accents */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(204,255,0,0.05),transparent_50%)]" />
      <div className="absolute top-0 inset-x-0 h-px bg-[#222222]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Bold Typography Taglines & Actions */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* System Status Mono Tag */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-xs font-mono uppercase tracking-[0.25em]">
              <span className="w-2 h-2 rounded-full bg-[#CCFF00] animate-pulse" />
              <span className="text-[#CCFF00] font-bold">SYSTEM.STATUS: ACTIVE</span>
              <span className="text-[#444444]">|</span>
              <span className="text-[#888888]">CONTRACT.X-RAY.v3</span>
            </div>

            {/* Massive Bold Headline */}
            <h1 className="text-5xl sm:text-7xl lg:text-8xl font-black text-[#F0F0F0] tracking-tighter uppercase leading-[0.88] break-words">
              <span className="block">Future</span>
              <span className="block text-transparent" style={{ WebkitTextStroke: '2px #CCFF00' }}>
                Contract
              </span>
              <span className="block text-[#CCFF00]">Inspection.</span>
            </h1>

            {/* Subtitle / Tagline */}
            <p className="text-xl sm:text-2xl font-bold text-[#F0F0F0] tracking-tight font-sans">
              "See the clauses that deserve a second look."
            </p>

            {/* Supporting Paragraph */}
            <p className="text-[#888888] text-base sm:text-lg leading-relaxed max-w-2xl font-normal">
              Upload a rental, freelance, or loan contract. ClauseX analyzes it clause by clause, highlights high-risk terms in real time, explains obligations in clear language, and equips you with custom negotiation scripts.
            </p>

            {/* Primary & Secondary Action CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
              <button
                onClick={onOpenUpload}
                className="px-8 py-4 rounded-xl text-base font-mono font-black uppercase tracking-wider text-black bg-[#CCFF00] hover:bg-[#b8e600] transition shadow-xl shadow-[#CCFF00]/10 flex items-center justify-center space-x-2 border border-[#CCFF00]"
                id="btn-hero-analyze"
              >
                <FileText className="w-5 h-5 text-black" />
                <span>Analyze Contract</span>
                <ArrowRight className="w-5 h-5 text-black" />
              </button>

              <button
                onClick={onLaunchDemo}
                className="px-8 py-4 rounded-xl text-base font-mono font-bold uppercase tracking-wider text-[#F0F0F0] bg-[#141414] border border-[#333333] hover:bg-[#1a1a1a] hover:border-[#CCFF00]/50 transition flex items-center justify-center space-x-2"
                id="btn-hero-try-demo"
              >
                <Zap className="w-5 h-5 text-[#CCFF00]" />
                <span>Try Instant Demo</span>
              </button>
            </div>

            {/* System Specs Checklist */}
            <div className="pt-4 grid sm:grid-cols-3 gap-3 text-xs font-mono uppercase tracking-wider text-[#888888]">
              <div className="flex items-center space-x-2 bg-[#141414] p-3 rounded-lg border border-[#222222]">
                <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0" />
                <span>Visual Risk Map</span>
              </div>
              <div className="flex items-center space-x-2 bg-[#141414] p-3 rounded-lg border border-[#222222]">
                <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0" />
                <span>Plain Language</span>
              </div>
              <div className="flex items-center space-x-2 bg-[#141414] p-3 rounded-lg border border-[#222222]">
                <CheckCircle2 className="w-4 h-4 text-[#CCFF00] shrink-0" />
                <span>Negotiation Scripts</span>
              </div>
            </div>

          </div>

          {/* Right Column: Realistic Contract Visual X-Ray Preview */}
          <div className="lg:col-span-5 relative">
            
            {/* Visual Container */}
            <div className="relative rounded-2xl bg-[#111111] border border-[#222222] p-6 shadow-2xl backdrop-blur-xl">
              
              {/* Header Bar */}
              <div className="flex items-center justify-between pb-4 border-b border-[#222222] mb-4">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-[#CCFF00]/80" />
                  <span className="text-xs font-mono text-[#888888] ml-2">Apartment_Lease_Agreement.pdf</span>
                </div>
                <div className="flex items-center space-x-1.5 text-[11px] font-mono text-[#CCFF00] bg-[#CCFF00]/10 px-2 py-0.5 rounded border border-[#CCFF00]/30">
                  <Search className="w-3 h-3" />
                  <span>X-RAY ACTIVE</span>
                </div>
              </div>

              {/* Document Text Mock with Interactive Clause Highlights */}
              <div className="space-y-3 font-serif text-xs text-[#F0F0F0] leading-relaxed bg-[#0A0A0A] p-4 rounded-xl border border-[#222222] max-h-[380px] overflow-y-auto">
                <p className="font-mono text-[11px] font-bold text-[#888888] uppercase tracking-widest mb-2">
                  SECTION 4. EARLY TERMINATION & FEES
                </p>

                {/* RED HIGHLIGHT CLAUSE */}
                <div
                  onClick={() => setActiveHighlight('red')}
                  className={`p-3 rounded-lg cursor-pointer transition-all border ${
                    activeHighlight === 'red'
                      ? 'bg-red-950/60 border-red-500 shadow-md text-red-100 ring-1 ring-red-500'
                      : 'bg-red-950/20 border-red-900/40 text-red-200/90 hover:bg-red-950/40'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-[10px] font-bold text-red-400 mb-1">
                    <span className="flex items-center space-x-1 uppercase">
                      <AlertTriangle className="w-3 h-3" />
                      <span>HIGH CONCERN • TERMINATION</span>
                    </span>
                    <span className="bg-red-900/60 px-1.5 py-0.5 rounded">6 Months Penalty</span>
                  </div>
                  "4.1 In the event Tenant seeks to vacate prior to lease end, Tenant agrees to pay liquidated damages equal to six (6) full months of rent ($14,400) immediately upon notice."
                </div>

                {/* AMBER HIGHLIGHT CLAUSE */}
                <div
                  onClick={() => setActiveHighlight('amber')}
                  className={`p-3 rounded-lg cursor-pointer transition-all border ${
                    activeHighlight === 'amber'
                      ? 'bg-amber-950/60 border-amber-500 shadow-md text-amber-100 ring-1 ring-amber-500'
                      : 'bg-amber-950/20 border-amber-900/40 text-amber-200/90 hover:bg-amber-950/40'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-[10px] font-bold text-amber-400 mb-1">
                    <span className="flex items-center space-x-1 uppercase">
                      <Info className="w-3 h-3" />
                      <span>REVIEW • NOTICE PERIOD</span>
                    </span>
                    <span className="bg-amber-900/60 px-1.5 py-0.5 rounded">90-Day Certified Mail</span>
                  </div>
                  "1.2 Automatic Renewal: Unless written notice of non-renewal is delivered via certified mail exactly 90 days prior to lease end, this agreement auto-renews at +12% rent."
                </div>

                {/* GREEN / LIME HIGHLIGHT CLAUSE */}
                <div
                  onClick={() => setActiveHighlight('green')}
                  className={`p-3 rounded-lg cursor-pointer transition-all border ${
                    activeHighlight === 'green'
                      ? 'bg-[#CCFF00]/20 border-[#CCFF00] shadow-md text-[#F0F0F0] ring-1 ring-[#CCFF00]'
                      : 'bg-[#CCFF00]/5 border-[#CCFF00]/20 text-[#F0F0F0]/90 hover:bg-[#CCFF00]/10'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-[10px] font-bold text-[#CCFF00] mb-1">
                    <span className="flex items-center space-x-1 uppercase">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>LOW CONCERN • PAYMENT</span>
                    </span>
                    <span className="bg-[#CCFF00]/20 px-1.5 py-0.5 rounded text-[#CCFF00]">Standard Due Date</span>
                  </div>
                  "2.1 Monthly Rent: Rent is $2,400 per month, due on the 1st day of each calendar month via online portal."
                </div>

              </div>

              {/* Dynamic Analysis Inspector Popover */}
              <div className="mt-4 p-3.5 rounded-xl bg-[#0A0A0A] border border-[#222222] text-xs font-sans space-y-1.5">
                {activeHighlight === 'red' && (
                  <div className="space-y-1 text-[#F0F0F0]">
                    <div className="flex items-center justify-between text-red-400 font-mono font-bold">
                      <span>X-RAY DIAGNOSTIC: EARLY TERMINATION</span>
                      <span className="text-[10px] bg-red-900/50 px-2 py-0.5 rounded">RISK 85/100</span>
                    </div>
                    <p className="text-[#888888]">
                      <strong className="text-[#F0F0F0]">Why flagged:</strong> 6 months rent penalty far exceeds typical 1–2 month market norms.
                    </p>
                    <div className="text-[11px] bg-red-950/50 p-2 rounded border border-red-900/50 text-red-200 font-mono">
                      💡 <strong>Negotiation:</strong> "Could we cap the early termination fee at two months rent with 30 days notice?"
                    </div>
                  </div>
                )}

                {activeHighlight === 'amber' && (
                  <div className="space-y-1 text-[#F0F0F0]">
                    <div className="flex items-center justify-between text-amber-400 font-mono font-bold">
                      <span>X-RAY DIAGNOSTIC: NOTICE PERIOD</span>
                      <span className="text-[10px] bg-amber-900/50 px-2 py-0.5 rounded">RISK 60/100</span>
                    </div>
                    <p className="text-[#888888]">
                      <strong className="text-[#F0F0F0]">Why flagged:</strong> Certified mail requirement can easily lead to missed deadlines and auto-renewal.
                    </p>
                    <div className="text-[11px] bg-amber-950/50 p-2 rounded border border-amber-900/50 text-amber-200 font-mono">
                      💡 <strong>Negotiation:</strong> "Can we allow written email notice 30 or 60 days prior to lease end?"
                    </div>
                  </div>
                )}

                {activeHighlight === 'green' && (
                  <div className="space-y-1 text-[#F0F0F0]">
                    <div className="flex items-center justify-between text-[#CCFF00] font-mono font-bold">
                      <span>X-RAY DIAGNOSTIC: RENT TERMS</span>
                      <span className="text-[10px] bg-[#CCFF00]/20 text-[#CCFF00] px-2 py-0.5 rounded">RISK 20/100</span>
                    </div>
                    <p className="text-[#888888]">
                      <strong className="text-[#F0F0F0]">Status:</strong> Standard monthly lease term with clear due date.
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
