import React from 'react';
import {
  FileUp,
  SearchCode,
  ShieldCheck,
  MessageSquare,
  Sparkles,
  AlertOctagon,
  Scale,
  Lock,
  ArrowRight,
  HelpCircle,
  FileText,
  DollarSign,
  Clock,
  Briefcase,
  Key,
  ShieldAlert
} from 'lucide-react';

interface LandingSectionsProps {
  onOpenUpload: () => void;
  onLaunchDemo: () => void;
}

export const LandingSections: React.FC<LandingSectionsProps> = ({ onOpenUpload, onLaunchDemo }) => {
  return (
    <div className="bg-[#0A0A0A] text-[#F0F0F0] space-y-24 py-16">
      
      {/* SECTION 1: HOW CLAUSEX WORKS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-[#CCFF00] text-xs font-mono font-bold uppercase tracking-[0.2em]">
            <Sparkles className="w-3.5 h-3.5 text-[#CCFF00]" />
            <span>4-STEP WORKFLOW</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-[#F0F0F0] uppercase tracking-tight">
            How ClauseX Inspects Your Contract
          </h2>
          <p className="text-[#888888] text-base">
            From raw upload to visual risk inspection in under 30 seconds — no complex legal jargon required.
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {/* Step 1 */}
          <div className="relative bg-[#111111] border border-[#222222] rounded-2xl p-6 hover:border-[#CCFF00] transition group">
            <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00] font-bold font-mono text-lg mb-4 group-hover:scale-110 transition-transform">
              01
            </div>
            <h3 className="text-lg font-bold text-[#F0F0F0] mb-2 flex items-center space-x-2 uppercase font-mono tracking-wide">
              <FileUp className="w-5 h-5 text-[#CCFF00]" />
              <span>Upload Contract</span>
            </h3>
            <p className="text-[#888888] text-sm leading-relaxed">
              Drop any rental lease, freelance contract, loan note, or service agreement in PDF or text format.
            </p>
          </div>

          {/* Step 2 */}
          <div className="relative bg-[#111111] border border-[#222222] rounded-2xl p-6 hover:border-[#CCFF00] transition group">
            <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00] font-bold font-mono text-lg mb-4 group-hover:scale-110 transition-transform">
              02
            </div>
            <h3 className="text-lg font-bold text-[#F0F0F0] mb-2 flex items-center space-x-2 uppercase font-mono tracking-wide">
              <SearchCode className="w-5 h-5 text-[#CCFF00]" />
              <span>Clause Extraction</span>
            </h3>
            <p className="text-[#888888] text-sm leading-relaxed">
              AI parses paragraph structure, isolates obligations, penalties, notice terms, and termination rights.
            </p>
          </div>

          {/* Step 3 */}
          <div className="relative bg-[#111111] border border-[#222222] rounded-2xl p-6 hover:border-[#CCFF00] transition group">
            <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00] font-bold font-mono text-lg mb-4 group-hover:scale-110 transition-transform">
              03
            </div>
            <h3 className="text-lg font-bold text-[#F0F0F0] mb-2 flex items-center space-x-2 uppercase font-mono tracking-wide">
              <ShieldCheck className="w-5 h-5 text-[#CCFF00]" />
              <span>Visual Contract X-Ray</span>
            </h3>
            <p className="text-[#888888] text-sm leading-relaxed">
              See color-coded clause highlights (Green, Amber, Red) mapped directly over your document text.
            </p>
          </div>

          {/* Step 4 */}
          <div className="relative bg-[#111111] border border-[#222222] rounded-2xl p-6 hover:border-[#CCFF00] transition group">
            <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center text-[#CCFF00] font-bold font-mono text-lg mb-4 group-hover:scale-110 transition-transform">
              04
            </div>
            <h3 className="text-lg font-bold text-[#F0F0F0] mb-2 flex items-center space-x-2 uppercase font-mono tracking-wide">
              <MessageSquare className="w-5 h-5 text-[#CCFF00]" />
              <span>Negotiate Safely</span>
            </h3>
            <p className="text-[#888888] text-sm leading-relaxed">
              Click any clause to read plain-language explanations, check flags, and copy ready-to-use negotiation wording.
            </p>
          </div>
        </div>
      </section>

      {/* SECTION 2: WHY CLAUSEX IS DIFFERENT (Anti-Chatbot) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#111111] border border-[#222222] rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="max-w-3xl space-y-4 mb-10">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-[#CCFF00] text-xs font-mono font-bold uppercase tracking-[0.2em]">
              <Scale className="w-3.5 h-3.5 text-[#CCFF00]" />
              <span>DESIGNED FOR INSTANT CLARITY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-[#F0F0F0] uppercase tracking-tight">
              Built for Visual Inspection, Not Casual Chat
            </h2>
            <p className="text-[#888888] text-base leading-relaxed">
              Generic AI chatbots force you to ask endless questions and wade through long walls of text. ClauseX treats your contract like a diagnostic scan.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Generic Chatbot */}
            <div className="bg-[#0A0A0A] border border-red-900/40 rounded-2xl p-6 space-y-4 opacity-75 hover:opacity-100 transition">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-red-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <AlertOctagon className="w-4 h-4" />
                  <span>Generic AI Chatbot / PDF Reader</span>
                </span>
                <span className="text-[10px] font-mono text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-900/50">
                  High Cognitive Load
                </span>
              </div>
              <ul className="space-y-3 text-sm text-[#888888]">
                <li className="flex items-start space-x-2">
                  <span className="text-red-500 font-bold text-base">✕</span>
                  <span>Forces you to ask "What should I look out for?" repeatedly.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-red-500 font-bold text-base">✕</span>
                  <span>Returns long, dry text bullet summaries disconnected from the original contract.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-red-500 font-bold text-base">✕</span>
                  <span>Lacks risk severity scores or structured category breakdowns.</span>
                </li>
              </ul>
            </div>

            {/* ClauseX */}
            <div className="bg-[#0A0A0A] border border-[#CCFF00] rounded-2xl p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-wider flex items-center space-x-1.5">
                  <Sparkles className="w-4 h-4 text-[#CCFF00]" />
                  <span>ClauseX Visual Contract X-Ray</span>
                </span>
                <span className="text-[10px] font-mono font-bold text-black bg-[#CCFF00] px-2 py-0.5 rounded border border-[#CCFF00]">
                  Instant Understanding
                </span>
              </div>
              <ul className="space-y-3 text-sm text-[#F0F0F0]">
                <li className="flex items-start space-x-2">
                  <span className="text-[#CCFF00] font-bold text-base">✓</span>
                  <span><strong>Visual X-Ray Map:</strong> High-risk clauses light up directly on the readable document.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-[#CCFF00] font-bold text-base">✓</span>
                  <span><strong>Deterministic Risk Score:</strong> 0–100 overall score and risk breakdown per category.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-[#CCFF00] font-bold text-base">✓</span>
                  <span><strong>Practical Negotiation Scripts:</strong> One-click copyable phrasing to email your landlord, client, or lender.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: RISK CATEGORIES COVERED */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#141414] border border-[#222222] text-[#CCFF00] text-xs font-mono font-bold uppercase tracking-[0.2em]">
            <ShieldAlert className="w-3.5 h-3.5 text-[#CCFF00]" />
            <span>COVERAGE SPECTRUM</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-[#F0F0F0] uppercase tracking-tight">
            Key Risk Categories We Scan
          </h2>
          <p className="text-[#888888] text-base">
            ClauseX compares contract provisions against standard fair reference patterns.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <DollarSign className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Payment & Fees</h3>
            <p className="text-xs text-[#888888]">Late fee compounding, hidden portal charges, payment delay penalties.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <AlertOctagon className="w-5 h-5 text-red-400" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Termination & Acceleration</h3>
            <p className="text-xs text-[#888888]">Excessive liquidated damages, immediate balance acceleration, early exit fees.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <Clock className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Notice & Auto-Renewal</h3>
            <p className="text-xs text-[#888888]">Restrictive certified mail traps, narrow non-renewal windows, auto-price hikes.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <Briefcase className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">IP & Non-Compete</h3>
            <p className="text-xs text-[#888888]">Unpaid copyright assignment, broad worldwide geographic work bans.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <Key className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Security Deposits</h3>
            <p className="text-xs text-[#888888]">Unreasonable deposit forfeiture rules, un-capped repair chargebacks.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <Scale className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Dispute & Venue</h3>
            <p className="text-xs text-[#888888]">Out-of-state mandatory arbitration, jury waivers, fee shifting.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <Lock className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Privacy & Data</h3>
            <p className="text-xs text-[#888888]">Employer wage contact, broad asset pledges, personal data sharing.</p>
          </div>

          <div className="p-4 rounded-xl bg-[#111111] border border-[#222222] space-y-2 hover:border-[#CCFF00]/50 transition">
            <ShieldCheck className="w-5 h-5 text-[#CCFF00]" />
            <h3 className="font-bold font-mono uppercase text-[#F0F0F0] text-sm">Indemnity & Liability</h3>
            <p className="text-xs text-[#888888]">Un-capped contractor indemnification, asymmetrical liability limits.</p>
          </div>
        </div>
      </section>

      {/* SECTION 4: TRUST & PRIVACY */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-[#CCFF00]/10 border border-[#CCFF00]/30 flex items-center justify-center shrink-0 text-[#CCFF00]">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold font-mono uppercase text-[#F0F0F0]">Privacy & Document Confidentiality</h3>
              <p className="text-[#888888] text-sm">
                Uploaded contracts are processed in temporary memory for analysis. Documents are never logged, publicly exposed, or sold.
              </p>
            </div>
          </div>
          <div className="shrink-0">
            <span className="text-xs font-mono font-bold text-[#CCFF00] bg-[#CCFF00]/10 px-3 py-1.5 rounded-lg border border-[#CCFF00]/30 uppercase tracking-widest">
              IN-MEMORY ANALYSIS ONLY
            </span>
          </div>
        </div>
      </section>

      {/* SECTION 5: LEGAL DISCLAIMER & FINAL CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <div className="bg-[#111111] border border-[#222222] rounded-3xl p-8 sm:p-12 space-y-6 max-w-4xl mx-auto">
          <h2 className="text-3xl font-black text-[#F0F0F0] uppercase tracking-tight">
            Ready to See What's In Your Contract?
          </h2>
          <p className="text-[#888888] text-base max-w-xl mx-auto">
            Try a built-in demo lease, freelance, or loan agreement or upload your own file for an instant visual contract inspection.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={onOpenUpload}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-mono font-black uppercase tracking-wider text-black bg-[#CCFF00] hover:bg-[#b8e600] transition shadow-lg shadow-[#CCFF00]/10 flex items-center justify-center space-x-2"
            >
              <FileUp className="w-5 h-5 text-black" />
              <span>Upload Your Contract</span>
            </button>

            <button
              onClick={onLaunchDemo}
              className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-mono font-bold uppercase tracking-wider text-[#F0F0F0] bg-[#141414] border border-[#333333] hover:bg-[#1a1a1a] transition flex items-center justify-center space-x-2"
            >
              <Sparkles className="w-5 h-5 text-[#CCFF00]" />
              <span>Try Demo Contract</span>
            </button>
          </div>

          <div className="pt-6 border-t border-[#222222] max-w-2xl mx-auto">
            <p className="text-[11px] text-[#888888] leading-relaxed font-mono uppercase tracking-wider">
              <strong>DISCLAIMER:</strong> ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
