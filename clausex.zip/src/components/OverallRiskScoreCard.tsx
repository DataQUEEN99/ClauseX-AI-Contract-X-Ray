import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, FileDown, Printer, Info, Sparkles } from 'lucide-react';
import { AnalysisResult } from '../types/contract';

interface OverallRiskScoreCardProps {
  analysis: AnalysisResult;
  onOpenReport: () => void;
}

export const OverallRiskScoreCard: React.FC<OverallRiskScoreCardProps> = ({
  analysis,
  onOpenReport,
}) => {
  const { overallRiskScore, riskLevelLabel, summary, categoryBreakdown, recommendations } = analysis;

  // Determine score color badge
  const getScoreColor = (score: number) => {
    if (score <= 25) return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', stroke: '#34d399' };
    if (score <= 50) return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', stroke: '#fbbf24' };
    if (score <= 75) return { text: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/30', stroke: '#fb923c' };
    return { text: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/30', stroke: '#f87171' };
  };

  const colors = getScoreColor(overallRiskScore);

  return (
    <div className="bg-[#111111] border border-[#222222] rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
      
      {/* Top Title & Score Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-[#222222]">
        
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-[0.2em]">
            <ShieldAlert className="w-4 h-4 text-[#CCFF00]" />
            <span>CONTRACT RISK DIAGNOSTIC</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-[#F0F0F0] uppercase tracking-tight">
            Overall Contract Risk
          </h2>
          <p className="text-xs font-mono text-[#888888]">
            Calculated deterministically from detected clause severity, confidence, and categories.
          </p>
        </div>

        {/* Score Dial & Signal Pill */}
        <div className="flex items-center space-x-5 bg-[#0A0A0A] p-4 rounded-2xl border border-[#222222]">
          
          {/* Circular Visual Dial */}
          <div className="relative w-20 h-20 flex items-center justify-center shrink-0">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-[#222222]"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                strokeWidth="3.5"
                strokeDasharray={`${overallRiskScore}, 100`}
                strokeLinecap="round"
                stroke={colors.stroke}
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className={`text-2xl font-black font-mono tracking-tighter ${colors.text}`}>
                {overallRiskScore}
              </span>
              <span className="text-[9px] font-mono text-[#888888] uppercase">/ 100</span>
            </div>
          </div>

          <div>
            <div className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-md text-xs font-mono font-black uppercase tracking-wider border ${colors.bg} ${colors.border} ${colors.text}`}>
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{riskLevelLabel}</span>
            </div>
            <p className="text-[11px] font-mono text-[#888888] mt-1.5 max-w-[200px]">
              {overallRiskScore > 50 ? 'Detailed review recommended before signing.' : 'Standard terms with minor advisory flags.'}
            </p>
          </div>

        </div>

      </div>

      {/* Summary & Category Breakdown Grid */}
      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Left Column: Summary & Recommendations */}
        <div className="lg:col-span-7 space-y-4">
          <div>
            <h3 className="text-xs font-mono font-bold text-[#888888] uppercase tracking-[0.15em] mb-2">
              EXECUTIVE SUMMARY
            </h3>
            <p className="text-sm text-[#F0F0F0] leading-relaxed bg-[#0A0A0A] p-4 rounded-xl border border-[#222222]">
              {summary}
            </p>
          </div>

          {recommendations && recommendations.length > 0 && (
            <div>
              <h3 className="text-xs font-mono font-bold text-[#CCFF00] uppercase tracking-[0.15em] mb-2 flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#CCFF00]" />
                <span>RECOMMENDED ACTION PLAN</span>
              </h3>
              <ul className="space-y-2 text-xs text-[#F0F0F0]">
                {recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start space-x-2 bg-[#0A0A0A] p-3 rounded-lg border border-[#222222]">
                    <span className="text-[#CCFF00] font-mono font-bold shrink-0">0{i + 1}.</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Right Column: Risk Category Breakdown Bars */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="text-xs font-mono font-bold text-[#888888] uppercase tracking-[0.15em]">
            CATEGORY RISK DENSITY
          </h3>

          <div className="space-y-3 bg-[#0A0A0A] p-4 rounded-xl border border-[#222222]">
            {categoryBreakdown && categoryBreakdown.length > 0 ? (
              categoryBreakdown.map((cat) => {
                const barColor = cat.score > 70 ? 'bg-red-500' : cat.score > 40 ? 'bg-amber-500' : 'bg-[#CCFF00]';
                return (
                  <div key={cat.category} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-bold text-[#F0F0F0] uppercase">{cat.category}</span>
                      <span className="font-mono text-[#888888]">{cat.score} / 100</span>
                    </div>
                    <div className="w-full h-2 bg-[#1A1A1A] rounded-full overflow-hidden border border-[#222222]">
                      <div
                        className={`h-full ${barColor} rounded-full transition-all duration-500`}
                        style={{ width: `${Math.max(8, cat.score)}%` }}
                      />
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-xs text-[#888888] font-mono">No category breakdown available.</p>
            )}
          </div>

          <button
            onClick={onOpenReport}
            className="w-full py-3 px-4 rounded-xl bg-[#141414] hover:bg-[#1a1a1a] text-[#F0F0F0] border border-[#333333] font-mono font-bold text-xs uppercase tracking-wider transition flex items-center justify-center space-x-2"
            id="btn-view-report-summary"
          >
            <FileDown className="w-4 h-4 text-[#CCFF00]" />
            <span>Generate & Download Report</span>
          </button>
        </div>

      </div>

    </div>
  );
};
