import express from 'express';
import path from 'path';
import { GoogleGenAI, Type } from '@google/genai';
import { calculateDeterministicRiskScore } from './src/utils/riskScoring.js';
import { Clause, RiskCategory, RiskLevel } from './src/types/contract.js';

const app = express();
const PORT = 3000;

// Middleware for parsing JSON requests (up to 20MB for PDF payloads)
app.use(express.json({ limit: '20mb' }));

// Health Check Endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'ClauseX Server', timestamp: new Date().toISOString() });
});

// Helper to initialize Gemini SDK safely
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Contract Analysis Endpoint
app.post('/api/analyze', async (req, res) => {
  try {
    const { text, pdfBase64, filename, mimeType } = req.body;

    if (!text && !pdfBase64) {
      return res.status(400).json({ error: 'Please provide either contract text or base64 PDF data.' });
    }

    const ai = getGeminiClient();

    if (!ai) {
      console.warn('GEMINI_API_KEY is not configured or placeholder. Returning fallback signal.');
      return res.status(503).json({
        error: 'Live AI API key is not configured.',
        isApiKeyMissing: true,
      });
    }

    const documentName = filename || 'Uploaded_Contract.pdf';
    console.log(`Processing contract analysis request for: ${documentName}`);

    // Build prompt and schema for structured JSON response
    const systemInstruction = `You are ClauseX, an elite AI contract visual inspector and risk analyzer.
Analyze the provided contract document. Extract clauses that present potential risks, unusual conditions, heavy penalties, restrictive covenants, or terms deserving second look for rental, freelance, loan, or service agreements.

IMPORTANT RULES:
1. Do NOT state a clause is "illegal" or "invalid". Use language like "Potentially risky", "Unusual clause", "Review recommended", "Potential concern", "Consider negotiation".
2. Categorize each flagged clause into one of: Payment, Termination, Penalty, Liability, Renewal, Privacy, Data usage, Deposit, Notice period, Dispute resolution, Non-compete, Intellectual property, Confidentiality, Service obligations, Other.
3. Classify riskLevel as LOW, MEDIUM, or HIGH.
4. Provide plain-language explanations, explain why it was flagged relative to fair reference patterns, what to check, and a ready-to-use negotiation phrase.
5. Provide concise top 3-4 overall recommendations.
6. Return strictly valid structured JSON matching the provided schema.`;

    const contentsParts: any[] = [];

    if (pdfBase64) {
      // Clean base64 string
      const cleanBase64 = pdfBase64.replace(/^data:[^;]+;base64,/, '');
      contentsParts.push({
        inlineData: {
          mimeType: mimeType || 'application/pdf',
          data: cleanBase64,
        },
      });
      contentsParts.push({
        text: 'Analyze this contract PDF file. Extract key clauses and perform risk inspection.',
      });
    } else {
      contentsParts.push({
        text: `Analyze the following contract document text:\n\n${text}`,
      });
    }

    // Call Gemini Model gemini-3.6-flash
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: { parts: contentsParts },
      config: {
        systemInstruction,
        temperature: 0.2,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            documentType: { type: Type.STRING, description: 'Type of contract e.g. Residential Lease, Service Agreement' },
            summary: { type: Type.STRING, description: 'Executive 2-sentence summary of overall findings' },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3-4 actionable next steps',
            },
            clauses: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  text: { type: Type.STRING, description: 'Direct quote or concise text snippet of the clause' },
                  category: { type: Type.STRING, description: 'Category e.g. Termination, Payment, Penalty' },
                  riskLevel: { type: Type.STRING, description: 'LOW, MEDIUM, or HIGH' },
                  confidence: { type: Type.NUMBER, description: 'Confidence score from 50 to 99' },
                  explanation: { type: Type.STRING, description: 'Plain-language explanation of what this means' },
                  whyFlagged: { type: Type.STRING, description: 'Why ClauseX flagged it vs reference patterns' },
                  whatToCheck: { type: Type.STRING, description: 'What to review or verify' },
                  negotiationSuggestion: { type: Type.STRING, description: 'Exact phrase to use in negotiation' },
                },
                required: ['id', 'text', 'category', 'riskLevel', 'explanation', 'whyFlagged', 'whatToCheck', 'negotiationSuggestion'],
              },
            },
          },
          required: ['documentType', 'summary', 'recommendations', 'clauses'],
        },
      },
    });

    const rawJsonText = response.text || '';
    let parsed: any;

    try {
      parsed = JSON.parse(rawJsonText);
    } catch (e) {
      console.error('Failed to parse Gemini JSON output directly. Raw response:', rawJsonText);
      return res.status(500).json({ error: 'Failed to parse AI response schema.' });
    }

    // Process and validate clauses
    const rawClauses: any[] = parsed.clauses || [];
    const validClauses: Clause[] = rawClauses.map((c, index) => {
      const riskLevel: RiskLevel = ['LOW', 'MEDIUM', 'HIGH'].includes(c.riskLevel?.toUpperCase())
        ? (c.riskLevel.toUpperCase() as RiskLevel)
        : 'MEDIUM';

      const validCategories: RiskCategory[] = [
        'Payment', 'Termination', 'Penalty', 'Liability', 'Renewal', 'Privacy',
        'Data usage', 'Deposit', 'Notice period', 'Dispute resolution',
        'Non-compete', 'Intellectual property', 'Confidentiality', 'Service obligations', 'Other'
      ];

      const category: RiskCategory = validCategories.find(cat => cat.toLowerCase() === c.category?.toLowerCase()) || 'Other';

      return {
        id: c.id || `clause-${index + 1}`,
        text: c.text || 'Clause text not extracted.',
        category,
        riskLevel,
        confidence: Math.min(99, Math.max(60, Number(c.confidence) || 85)),
        explanation: c.explanation || 'Review recommended for potential impact.',
        whyFlagged: c.whyFlagged || 'Clause deviates from standard fair-reference templates.',
        whatToCheck: c.whatToCheck || 'Review with standard template references.',
        negotiationSuggestion: c.negotiationSuggestion || 'Could we review and clarify this provision?',
      };
    });

    // Compute deterministic risk scores
    const { overallRiskScore, riskLevelLabel, categoryBreakdown } = calculateDeterministicRiskScore(validClauses);

    const result = {
      documentName,
      documentType: parsed.documentType || 'Contract Document',
      overallRiskScore,
      riskLevelLabel,
      summary: parsed.summary || 'ClauseX completed visual inspection of this document.',
      clauses: validClauses,
      categoryBreakdown,
      recommendations: parsed.recommendations || ['Review flagged clauses in detail.', 'Consider proposing suggested negotiation wording.'],
      disclaimer: 'ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional.',
      analyzedAt: new Date().toISOString(),
      isFallback: false,
    };

    return res.json(result);
  } catch (error: any) {
    console.error('Error during contract analysis endpoint:', error);
    return res.status(500).json({
      error: error.message || 'An unexpected error occurred during analysis.',
      details: String(error),
    });
  }
});

// Vite Middleware for Dev or Static Serving for Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ClauseX server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
