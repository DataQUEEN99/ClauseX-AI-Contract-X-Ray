# ClauseX — AI X-Ray for Contracts

> **See the clauses that deserve a second look.**

ClauseX is a visual contract inspection and risk analysis tool built for renters, freelancers, independent contractors, and borrowers. It transforms complex legal documents into an interactive, color-coded Contract X-Ray — highlighting potentially risky clauses, explaining them in plain language, and offering actionable negotiation questions.

---

## 🎯 Problem

Every day, millions of people sign rental agreements, freelance contracts, loan notes, and service agreements without knowing which specific provisions pose financial or legal risks. Traditional AI tools force users into long chatbot conversations or yield dense summary walls of text disconnected from the original contract.

## ⚡ Solution

ClauseX treats contract review like a visual diagnostic scan:
1. **Upload Contract:** PDF or plain text intake with in-memory privacy.
2. **Clause Extraction:** AI detects section boundaries, obligations, penalties, and termination rights.
3. **Visual Contract X-Ray:** Color-coded clause highlights (**Red** = High Concern, **Amber** = Review, **Green** = Low Concern) directly mapped over readable document text.
4. **Diagnostic Inspector:** Click any clause for plain-language explanations, benchmark comparisons, and copyable negotiation scripts.
5. **Deterministic Risk Score:** 0–100 overall score and risk density breakdown across categories (Payment, Termination, Penalty, Liability, Privacy, etc.).

---

## ✨ Core Features

- **Visual Contract X-Ray:** Interactive document viewer with highlighted clauses and filter bar.
- **Diagnostic Panel:** Plain-language breakdown, reason for flag, verification checklist, and ready-to-use negotiation phrasing.
- **Deterministic Risk Engine:** Weighted scoring model (0–100) combining severity, confidence, and category density.
- **1-Click Judge Demo Mode:** 60-second instant showcase sequence with built-in synthetic lease, freelance, and loan agreements.
- **Printable Analysis Report:** 1-page summary report formatted for print or PDF download.
- **Fail-Safe Fallback Engine:** Built-in synthetic dataset ensuring zero downtime even if network or API keys are unavailable.

---

## 🛠️ Tech Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS, Lucide Icons, Motion, Canvas-Confetti
- **Backend:** Node.js, Express, ESBuild, TSX
- **AI Integration:** Google Gemini API (`@google/genai`) with `gemini-3.6-flash`
- **Deployment:** Google Cloud Run / AI Studio container environment

---

## 🚀 How to Run Locally

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment variables:**
   Copy `.env.example` to `.env`:
   ```env
   GEMINI_API_KEY="your-gemini-api-key"
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

4. **Build for production:**
   ```bash
   npm run build
   npm start
   ```

---

## 🎬 60-Second Demo Instructions

1. Click **"Launch Demo"** in the top navigation or hero section.
2. Watch the animated **AI X-Ray processing sequence** extract sections and detect terms.
3. Inspect the **Overall Risk Score (78/100 — VERY HIGH REVIEW SIGNAL)** and category breakdown.
4. Click on the **Red High Concern Clause** ("Section 4.1 Early Termination Fee").
5. Review the **Plain-Language Explanation**, **Why Flagged**, and click **"Copy Wording"** on the suggested negotiation text.
6. Click **"Generate & Download Report"** to view the printable summary.

---

## ⚖️ Legal Disclaimer

ClauseX provides AI-assisted information for educational and decision-support purposes. It is not legal advice and does not replace a qualified legal professional. ClauseX does not guarantee legal outcomes or invalidity of contract terms.
